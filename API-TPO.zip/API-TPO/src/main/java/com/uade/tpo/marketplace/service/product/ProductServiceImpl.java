package com.uade.tpo.marketplace.service.product;

import com.uade.tpo.marketplace.controllers.product.CreateProductRequest;
import com.uade.tpo.marketplace.entity.Category;
import com.uade.tpo.marketplace.entity.Product;
import com.uade.tpo.marketplace.exceptions.*;
import com.uade.tpo.marketplace.repository.ProductRepository;
import com.uade.tpo.marketplace.service.category.CategoryService;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryService categoryService;

    public Product createProduct(CreateProductRequest createProductRequest)
            throws ProductAlreadyExistsException, CategoryDuplicateException, CategoryNotFoundException {
        // verifica que no exista un producto con ese nombre
        if (productRepository.findByNameEqualsIgnoreCase(createProductRequest.getName()).isPresent()) {
            throw new ProductAlreadyExistsException();
        }

        // Si incluye categoria en la solicitud, buscarla y si no existe lanzar error
        Category category = null;
        if (createProductRequest.getCategoryName() != null) {
            category = categoryService.getCategoryByName(createProductRequest.getCategoryName()).orElseThrow(
                    () -> new CategoryNotFoundException()
            );
        }

        // TODO: Esto deberia usar DTOs y mappers
        Product product = new Product();

        // Si la categoria existe agregarla al producto antes de guardar
        product.setCategory(category);
        product.setName(createProductRequest.getName());
        product.setDescription(createProductRequest.getDescription());
        product.setPrice(createProductRequest.getPrice());
        product.setStock(createProductRequest.getStock());
        product.setDiscount(createProductRequest.getDiscount());

        return productRepository.save(product);
    }

    public Page<Product> getAllProducts(PageRequest pageable) {
        // Obtener todos los productos
        return productRepository.findAll(pageable);
    }

    public List<Product> getProductsByName(String productName, PageRequest request) {
        // Obtener todos los productos que contengan el productName ignorando casing
        return productRepository.findByNameContainingIgnoreCase(productName, request);
    }

    public List<Product> getProductsByCategory(String categoryName)
            throws CategoryNotFoundException {
        // Validar que exista la categoria
        Category category = categoryService.getCategoryByName(categoryName).orElseThrow(
                () -> new CategoryNotFoundException()
        );

        return productRepository.findByCategoryId(category.getId());
    }

    public Product getProductById(long productId)
            throws ProductNotFoundException {
        Optional<Product> product = productRepository.findById(productId);
        if (product.isEmpty()) {
            throw new ProductNotFoundException();
        }
        return product.get();
    }

    public Product setStock(long productId, int stock)
            throws ProductNotFoundException {
        // Validar que el stock sea positivo
        if (stock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo");
        }

        // Validar que el producto exista
        Product product = productRepository.findById(productId).orElseThrow(
                () -> new ProductNotFoundException()
        );

        product.setStock(stock);
        return productRepository.save(product);
    }

    @Override
    public Product getProductStock(long productId) throws ProductNotFoundException {
        return getProductById(productId);
    }

    @Override
    @Transactional
    public void deleteProduct(long productId)
            throws ProductNotFoundException {
        productRepository.findById(productId).orElseThrow(
                () -> new ProductNotFoundException()
        );
        productRepository.deleteById(productId);
    }



    @Override
    public Product setDiscount(long productId, int discount) throws ProductNotFoundException {
        // Validar que el descuento sea entre 0 y 100
        if (discount < 0 || discount > 100) {
            throw new IllegalArgumentException("El descuento debe estar entre 0 y 100");
        }

        // Validar que el producto exista
        Product product = productRepository.findById(productId).orElseThrow(
                () -> new ProductNotFoundException()
        );

        product.setDiscount(discount);
        return productRepository.save(product);
    }

    @Override
    public Product addImage(long productId) throws ProductNotFoundException {
        // Validar que el producto exista
        return productRepository.findById(productId).orElseThrow(
                () -> new ProductNotFoundException()
        );
    }

    @Override
    public void decrementProductStock(long productId, int quantity)
            throws ProductNotFoundException, InsufficientStockException {
        productRepository.findById(productId).orElseThrow(
                () -> new ProductNotFoundException()
        );
        productRepository.decrementProductStock(productId, quantity);
    }

    public List<Product> getProducts(String name, String category, String sort, PageRequest pageRequest)
            throws CategoryNotFoundException, SortCriteriaNotFound, NoProductsFoundException {
        // TODO: Probar con paginado
        // Validar que exista la categoría solo si se proporciona
        Category categoryFound = null;
        if (category != null && !category.isBlank()) {
            categoryFound = categoryService.getCategoryByName(category)
                    .orElseThrow(CategoryNotFoundException::new);
        }

        // Obtener los productos que coincidan con el nombre y la categoría (si se proporciona)
        List<Product> products;
        if (categoryFound != null) {
            products = productRepository.findByNameContainingIgnoreCaseAndCategoryName(
                    name != null ? name : "", categoryFound.getName(), pageRequest);
        } else {
            products = productRepository.findByNameContainingIgnoreCase(name != null ? name : "", pageRequest);
        }

        // Si no se encontraron productos, lanzar excepción
        if (products.isEmpty()) {
            throw new NoProductsFoundException();
        }

        // Ordenar los productos según el criterio solicitado, si se proporciona
        if (sort != null && !sort.isBlank()) {
            products = sortProductsByCriteria(products, sort);
        }

        return products;
    }

    private List<Product> sortProductsByCriteria(List<Product> products, String sort)
            throws SortCriteriaNotFound {
        if (products.size() > 1) {
            if (sort.equals("price;asc")) {
                products = products.stream()
                        .sorted(Comparator.comparing(Product::getPrice))
                        .collect(Collectors.toList());
            } else if (sort.equals("price;desc")) {
                products = products.stream()
                        .sorted(Comparator.comparing(Product::getPrice).reversed())
                        .collect(Collectors.toList());
            } else {
                throw new SortCriteriaNotFound();
            }
        }
        return products;
    }

    @Override
    public Product removeDiscount(long productId) throws ProductNotFoundException {
        Product product = productRepository.findById(productId)
                .orElseThrow(ProductNotFoundException::new);

        product.setDiscount(0);
        return productRepository.save(product);
    }

    @Override
    public List<Product> removeDiscountAll() {
        List<Product> products = productRepository.findAll();

        for (Product product : products) {
            product.setDiscount(0);
        }

        return productRepository.saveAll(products);
    }

    @Override
    public List<Product> removeDiscountByCategory(long categoryId) throws CategoryNotFoundException {
        categoryService.getCategoryById(categoryId)
                .orElseThrow(CategoryNotFoundException::new);

        List<Product> products = productRepository.findByCategoryId(categoryId);
        for (Product product : products) {
            product.setDiscount(0);
        }

        return productRepository.saveAll(products);
    }

    @Override
    public List<Product> setDiscountAll(int discount)
            throws InvalidDiscountException {
        // Validar que el descuento sea entre 0 y 100
        if (discount < 0 || discount > 100) {
            throw new InvalidDiscountException();
        }

        // Buscar todos los productos
        List<Product> products = productRepository.findAll();

        // Aplicar el descuento a cada producto
        for (Product product : products) {
            product.setDiscount(discount);
        }

        // Guardar todos los cambios
        return productRepository.saveAll(products);
    }

    @Override
    public List<Product> setDiscountByCategory(long categoryId, int discount)
            throws CategoryNotFoundException, InvalidDiscountException {
        if (discount < 0 || discount > 100) {
            throw new InvalidDiscountException();
        }

        // Validar que la categoría exista
        categoryService.getCategoryById(categoryId)
                .orElseThrow(CategoryNotFoundException::new);

        // Buscar productos que tengan esa categoría
        List<Product> products = productRepository.findByCategoryId(categoryId);

        for (Product product : products) {
            product.setDiscount(discount);
        }

        return productRepository.saveAll(products);
    }

}
