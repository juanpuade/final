package com.uade.tpo.marketplace.controllers.category;

import com.uade.tpo.marketplace.exceptions.CategoryNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.uade.tpo.marketplace.entity.Category;
import com.uade.tpo.marketplace.exceptions.CategoryDuplicateException;
import com.uade.tpo.marketplace.service.category.CategoryService;
import java.net.URI;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    @PreAuthorize("hasRole('SELLER') or hasRole('USER')")
    @Operation(
            summary = "Obtiene todas las categorías con paginación opcional",
            description = "Si no se proporcionan los parámetros de paginación, se devuelven todas las categorías")
    public ResponseEntity<Page<Category>> getCategories(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        if (page == null || size == null)
            return ResponseEntity.ok(categoryService.getCategories(PageRequest.of(0, Integer.MAX_VALUE)));
        return ResponseEntity.ok(categoryService.getCategories(PageRequest.of(page, size)));
    }

    @GetMapping("/{categoryId}")
    @PreAuthorize("hasRole('SELLER') or hasRole('USER')")
    @Operation(
            summary = "Obtiene una categoría por su ID",
            description = "Devuelve la categoría correspondiente al ID proporcionado")
    public ResponseEntity<Category> getCategoryById(@PathVariable Long categoryId) {
        Optional<Category> result = categoryService.getCategoryById(categoryId);
        if (result.isPresent())
            return ResponseEntity.ok(result.get());
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/name/{name}")
    @Operation(
            summary = "Obtiene una categoría por su nombre",
            description = "Devuelve la categoría correspondiente al nombre proporcionado")
    @PreAuthorize("hasRole('SELLER') or hasRole('USER')")
    public ResponseEntity<Category> getCategoryByName(@PathVariable(required = true) String name) {
        Optional<Category> result = categoryService.getCategoryByName(name);
        if (result.isPresent())
            return ResponseEntity.ok(result.get());
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Crea una nueva categoría",
            description = "Crea una nueva categoría con la descripción proporcionada")
    public ResponseEntity<Category> createCategory(@RequestBody CreateCategoryRequest categoryRequest)
            throws CategoryDuplicateException {
        Category result = categoryService.createCategory(categoryRequest);
        return ResponseEntity.created(URI.create("/categories/" + result.getId())).body(result);
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Borra una categoría por su ID",
            description = "Borra una categoriía con el ID proporcionado")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<Void> deleteCategory(@PathVariable(required = true) long id)
            throws CategoryNotFoundException {
        categoryService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }

}
