package com.uade.tpo.marketplace.service.image;

import com.uade.tpo.marketplace.entity.Image;
import org.springframework.stereotype.Service;

@Service
public interface ImageService {

    public Image create(Image image);

    public Image viewById(long id);

    public Image getImageForProduct(long productId);

}
