package com.uade.tpo.marketplace.service.order;

import com.uade.tpo.marketplace.controllers.order.CreateOrderRequest;
import com.uade.tpo.marketplace.entity.Order;
import com.uade.tpo.marketplace.exceptions.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

public interface OrderService {

    Page<Order> getOrders(long userId, PageRequest pageRequest)
            throws UserNotFoundException, NoOrdersFoundException;

    Order createOrder(CreateOrderRequest request, long userId)
            throws OrderCannotBeFulfilledException, ProductNotFoundException,
            UserNotFoundException, InsufficientStockException;

    Order getActiveOrder(Long userId)
            throws UserNotFoundException, NoActiveUnpaidOrderFoundException;

}
