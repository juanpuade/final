package com.uade.tpo.marketplace.service.product;

import com.uade.tpo.marketplace.controllers.product.CreateProductRequest;
import com.uade.tpo.marketplace.entity.Product;
import com.uade.tpo.marketplace.exceptions.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import java.util.List;

public interface ProductService {

    Product createProduct(CreateProductRequest product) throws ProductAlreadyExistsException, CategoryDuplicateException, CategoryNotFoundException;

    Page<Product> getAllProducts(PageRequest pageRequest);

    List<Product> getProducts(String name, String category, String sort, PageRequest request) throws CategoryNotFoundException, SortCriteriaNotFound, NoProductsFoundException;

    List<Product> getProductsByName(String productName, PageRequest request);

    List<Product> getProductsByCategory(String categoryName) throws CategoryNotFoundException;

    Product getProductById(long productId) throws ProductNotFoundException;

    Product setStock(long productId, int stock) throws ProductNotFoundException;

    Product getProductStock(long productId) throws ProductNotFoundException;

    void deleteProduct(long productId) throws ProductNotFoundException;

    Product setDiscount(long productId, int discount) throws ProductNotFoundException;

    List<Product> setDiscountAll(int discount) throws InvalidDiscountException;

    List<Product> setDiscountByCategory(long category, int discount) throws CategoryNotFoundException, InvalidDiscountException;

    Product removeDiscount(long productId) throws ProductNotFoundException;

    List<Product> removeDiscountAll();

    List<Product> removeDiscountByCategory(long categoryId) throws CategoryNotFoundException;

    Product addImage(long productId) throws ProductNotFoundException;

    void decrementProductStock(long productId, int quantity) throws ProductNotFoundException, InsufficientStockException;

}
