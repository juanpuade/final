package com.uade.tpo.marketplace.controllers.product;

import com.uade.tpo.marketplace.entity.Product;
import com.uade.tpo.marketplace.exceptions.*;
import com.uade.tpo.marketplace.service.product.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;


@RestController
@CrossOrigin(origins = "http://localhost:3001")
@RequestMapping("products")
@AllArgsConstructor
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    @PreAuthorize("hasRole('SELLER')")
    @Operation(summary = "Crear producto", description = "Crea un nuevo producto en el sistema")
    public ResponseEntity<Product> createProduct(@RequestBody CreateProductRequest product)
            throws ProductAlreadyExistsException, CategoryDuplicateException,
            CategoryNotFoundException {
        return ResponseEntity.ok(productService.createProduct(product));
    }

    @GetMapping
    @Operation(
            summary = "Obtener productos",
            description = "Obtiene una lista de productos filtrados por nombre, categoría y ordenados según criterios especificados")
    public ResponseEntity<List<Product>> getProducts(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String sort,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size)
            throws CategoryNotFoundException, SortCriteriaNotFound,
            NoProductsFoundException {
        if (page == null || size == null)
            return ResponseEntity.ok(productService.getProducts(name, category, sort, PageRequest.of(0, Integer.MAX_VALUE)));
        return ResponseEntity.ok(productService.getProducts(name, category, sort, PageRequest.of(0, Integer.MAX_VALUE)));
    }

    @GetMapping("/all")
    @Operation(
            summary = "Obtiene todos los productos con paginación opcional",
            description = "Si no se proporcionan los parámetros de paginación, se devuelven todos los productos")
    public ResponseEntity<Page<Product>> getAllProducts(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        if (page == null || size == null)
            return ResponseEntity.ok(productService.getAllProducts(PageRequest.of(0, Integer.MAX_VALUE)));
        return ResponseEntity.ok(productService.getAllProducts(PageRequest.of(page, size)));

    }

    @GetMapping("/name")
    @Operation(summary = "Obtener productos por nombre", description = "Obtiene una lista de productos que coinciden con el nombre especificado")
    public ResponseEntity<List<Product>> getProductsByName(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = true) String name) {
        // TODO: Probar con paginado
        if (page == null || size == null)
            return ResponseEntity.ok(productService.getProductsByName(name, PageRequest.of(0, Integer.MAX_VALUE)));
        return ResponseEntity.ok(productService.getProductsByName(name, PageRequest.of(page,size)));
    }

    @GetMapping("/category")
    @Operation(
            summary = "Obtener productos por categoría",
            description = "Obtiene una lista de productos que pertenecen a la categoría especificada")
    public ResponseEntity<List<Product>> getProductsByCategory(
            @RequestParam(required = true) String categoryName) throws CategoryNotFoundException {
        return ResponseEntity.ok(productService.getProductsByCategory(categoryName));
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Obtener producto por ID",
            description = "Obtiene los detalles de un producto específico mediante su ID")
    public ResponseEntity<Product> getProductById(@PathVariable long id)
            throws ProductNotFoundException {
        return ResponseEntity.ok(productService.getProductById(id));
    }

    @PutMapping("/{id}/stock/{quantity}")
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Actualizar stock de producto",
            description = "Actualiza la cantidad de stock disponible para un producto específico")
    public ResponseEntity<Product> setStock(
            @PathVariable(required = true) long id,
            @PathVariable(required = true) int quantity)
            throws ProductNotFoundException {
        Product product = productService.setStock(id, quantity);
        return ResponseEntity.ok(product);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Eliminar producto",
            description = "Elimina un producto específico del sistema mediante su ID")
    public ResponseEntity<Void> deleteProduct(@PathVariable long id) throws ProductNotFoundException {
        productService.deleteProduct(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/discount/{discount}")
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Aplicar descuento a producto",
            description = "Aplica un descuento específico a un producto mediante su ID")
    public ResponseEntity<Product> setDiscount(
            @PathVariable(required = true) long id,
            @PathVariable(required = true) int discount)
            throws ProductNotFoundException {
        Product product = productService.setDiscount(id, discount);
        return ResponseEntity.ok(product);
    }

    @PutMapping("/discount/{discount}")
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Aplicar descuento a todos los productos",
            description = "Aplica un descuento a todos los productos disponibles")
    public ResponseEntity<List<Product>> setDiscountAll(
            @PathVariable int discount) throws InvalidDiscountException {
        List<Product> updatedProducts = productService.setDiscountAll(discount);
        return ResponseEntity.ok(updatedProducts);
    }

    @PutMapping("/category/{categoryId}/discount/{discount}")
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Aplicar descuento por categoría",
            description = "Aplica un descuento a todos los productos de una categoría usando el ID de la categoría")
    public ResponseEntity<List<Product>> setDiscountByCategory(
            @PathVariable long categoryId,
            @PathVariable int discount)
            throws CategoryNotFoundException, InvalidDiscountException {
        List<Product> updatedProducts = productService.setDiscountByCategory(categoryId, discount);
        return ResponseEntity.ok(updatedProducts);
    }
    
    @PutMapping("/{id}/discount/remove")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<Product> removeDiscount(@PathVariable long id)
            throws ProductNotFoundException {
        Product product = productService.removeDiscount(id);   // coincide con service
        return ResponseEntity.ok(product);
    }

    @PutMapping("/discount/remove")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<List<Product>> removeDiscountAll() {
        List<Product> products = productService.removeDiscountAll();
        return ResponseEntity.ok(products);
    }

    @PutMapping("/category/{categoryId}/discount/remove")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<List<Product>> removeDiscountByCategory(@PathVariable long categoryId)
            throws CategoryNotFoundException {
        List<Product> products = productService.removeDiscountByCategory(categoryId); // coincide con service
        return ResponseEntity.ok(products);
    }

    public ProductService getProductService() {
        return productService;
    }

    public void setProductService(ProductService productService) {
        this.productService = productService;
    }

}
