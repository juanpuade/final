package com.uade.tpo.marketplace.service.order;

import com.uade.tpo.marketplace.controllers.order.CreateOrderRequest;
import com.uade.tpo.marketplace.entity.*;
import com.uade.tpo.marketplace.exceptions.*;
import com.uade.tpo.marketplace.repository.OrderRepository;
import com.uade.tpo.marketplace.repository.UserRepository;
import com.uade.tpo.marketplace.service.auth.JwtService;
import com.uade.tpo.marketplace.service.product.ProductService;
import com.uade.tpo.marketplace.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.ArrayList;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Page<Order> getOrders(long userId, PageRequest request)
            throws NoOrdersFoundException {
        Page<Order> orders = orderRepository.findByUserId(userId, request);
        if (orders.isEmpty()) {
            throw new NoOrdersFoundException();
        }
        return orders;
    }

    @Override
    public Order createOrder(CreateOrderRequest request, long userId)
            throws OrderCannotBeFulfilledException, UserNotFoundException,
            ProductNotFoundException, InsufficientStockException {
        Order order = new Order();
        order.setItems(new ArrayList<>());

        // Validar ppor cada producto si hay stokc suficiente para la orden
        for (var product : request.getItems()) {

            // Se obtienen los productos
            Product productStock = productService.getProductStock(product.getProductId());
            // Si el stock existente es menor al solicitado, se lanza la excepcion
            if (productStock.getStock() < product.getQuantity()) {
                throw new OrderCannotBeFulfilledException();
            }
            // Si hay stock suficiente, se agrega el item a la orden
            order.getItems().add(new OrderItem(product.getQuantity(), productStock, order));
        }

        // Todos los productos tienen stock suficiente
        // Descontamos el stock de cada producto
        for (var product : request.getItems()) {
            // Si el stock es suficiente, se descuenta y si no, se lanza la excepcion
            productService.decrementProductStock(product.getProductId(), product.getQuantity());
        }

        // Crear la orden
        order.setUser(userService.getUserById(userId));
        order.setOrderDate(LocalDateTime.now());
        order.setPaid(false);
        userRepository.save(order.getUser());

        // Totalizamos el precio de la orden
        order.calculateTotalPrice();
        return orderRepository.save(order);
    }

    @Override
    public Order getActiveOrder(Long userId)
            throws NoActiveUnpaidOrderFoundException {
        return orderRepository.findActiveUnpaidOrderByUserId(userId).orElseThrow(
                () -> new NoActiveUnpaidOrderFoundException()
        );
    }

}
