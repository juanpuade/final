package com.uade.tpo.marketplace.service.image;

import com.uade.tpo.marketplace.entity.Image;
import com.uade.tpo.marketplace.repository.ImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ImageServiceImpl implements ImageService {

    @Autowired
    private ImageRepository imageRepository;

    @Override
    public Image create(Image image) {
        return imageRepository.save(image);
    }

    @Override
    public Image viewById(long id) {
        Optional<Image> optional = imageRepository.findById(id);
        return optional.orElse(null);
    }

    @Override
    public Image getImageForProduct(long productId) {
        List<Image> byProductId = imageRepository.findByProductId(productId);
        if (byProductId == null || byProductId.isEmpty()) {
            return null;
        }
        return byProductId.get(0);
    }
}
