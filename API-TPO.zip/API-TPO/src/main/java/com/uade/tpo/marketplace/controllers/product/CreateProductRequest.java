package com.uade.tpo.marketplace.controllers.product;

import lombok.Data;

@Data
public class CreateProductRequest {

    private String name;

    private int stock;

    private String description;

    private Double price;

    private int discount;

    private String categoryName;

}
