package com.uade.tpo.marketplace.controllers.order;

import com.uade.tpo.marketplace.entity.Order;
import com.uade.tpo.marketplace.exceptions.*;
import com.uade.tpo.marketplace.service.auth.JwtService;
import com.uade.tpo.marketplace.service.order.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private JwtService jwtService;

    @GetMapping("/{userId}/all")
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Obtener las ordenes de un usuario",
            description = "Obtiene una lista de ordenes de un usuario especifico")
    public ResponseEntity<Page<Order>> getOrders(
            @PathVariable long userId,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size)
            throws UserNotFoundException, NoOrdersFoundException {
        if (page == null || size == null)
            return ResponseEntity.ok(orderService.getOrders(userId, PageRequest.of(0, Integer.MAX_VALUE)));
        return ResponseEntity.ok(orderService.getOrders(userId, PageRequest.of(page,size)));
    }

    @PutMapping("/pay")
    @PreAuthorize("hasRole('USER')")
    @Operation(
            summary = "Permite realizar el pago de una orden",
            description = "Permite realizar el pago de una orden")
    public ResponseEntity<String> payOrder(
            HttpServletRequest request
    ) throws UserNotFoundException {
        Long userId = jwtService.getUserId(request);
        return ResponseEntity.ok("Pago realizado con exito");
    }

    @GetMapping("/{userId}/active")
    @PreAuthorize("hasRole('USER')")
    @Operation(
            summary = "Obtener la orden activa de un usuario",
            description = "Obtener la orden activa de un usuario")
    public ResponseEntity<Order> getActiveOrder(HttpServletRequest request)
            throws UserNotFoundException, NoActiveUnpaidOrderFoundException {
        Long userId = jwtService.getUserId(request);
        return ResponseEntity.ok(orderService.getActiveOrder(userId));
    }

    @PostMapping
    @PreAuthorize("hasRole('USER')")
    @Operation(
            summary = "Permite crear una orden",
            description = "Permite crear una orden")
    public ResponseEntity<Order> createOrder(
            @RequestBody CreateOrderRequest request, HttpServletRequest servletRequest)
            throws ProductNotFoundException, UserNotFoundException,
            OrderCannotBeFulfilledException, InsufficientStockException {
        Long userId = jwtService.getUserId(servletRequest);
        return ResponseEntity.ok(orderService.createOrder(request, userId));
    }

}
