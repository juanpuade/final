package com.uade.tpo.marketplace.service.category;

import java.util.List;
import java.util.Optional;
import com.uade.tpo.marketplace.controllers.category.CreateCategoryRequest;
import com.uade.tpo.marketplace.exceptions.CategoryNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.uade.tpo.marketplace.entity.Category;
import com.uade.tpo.marketplace.exceptions.CategoryDuplicateException;
import com.uade.tpo.marketplace.repository.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public Page<Category> getCategories(PageRequest pageable) {
        return categoryRepository.findAll(pageable);
    }

    public Optional<Category> getCategoryById(Long categoryId) {
        return categoryRepository.findById(categoryId);
    }

    public Optional<Category> getCategoryByName(String name) {
        return categoryRepository.findByNameContainingIgnoreCase(name);
    }

    public Category createCategory(CreateCategoryRequest request)
            throws CategoryDuplicateException {
        List<Category> categories = categoryRepository.findByNameEqualsIgnoreCase(request.getName());
        if (categories.size() > 0 ) {
            throw new CategoryDuplicateException();
        }
        Category category = new Category(request.getName(), request.getDescription());
        return categoryRepository.save(category);
    }

    @Override
    public void deleteCategory(long categoryId)
            throws CategoryNotFoundException {
        categoryRepository.findById(categoryId).orElseThrow(
                () -> new CategoryNotFoundException()
        );
        categoryRepository.deleteById(categoryId);
    }

}
