package com.uade.tpo.marketplace.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.uade.tpo.marketplace.entity.Category;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

    List<Category> findByNameEqualsIgnoreCase(String name);

    @Query(value = "select c from Category c where c.description = ?1")
    List<Category> findByDescription(String description);

    Optional<Category> findByNameContainingIgnoreCase(String name);

    void deleteById(long id);

}
