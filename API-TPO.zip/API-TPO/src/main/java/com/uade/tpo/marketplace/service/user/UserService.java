package com.uade.tpo.marketplace.service.user;
import java.util.List;
import com.uade.tpo.marketplace.controllers.user.UserRequest;
import com.uade.tpo.marketplace.entity.User;
import com.uade.tpo.marketplace.exceptions.UserNotFoundException;

public interface UserService {

    User getUserById(long userId) throws UserNotFoundException;

    User updateUser(UserRequest userRequest) throws UserNotFoundException;

    void deleteUser(long userId);

    User getUserByEmail(String email) throws UserNotFoundException;

    List<User> getAllUsers();

}
