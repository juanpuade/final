package com.uade.tpo.marketplace.service.user;

import com.uade.tpo.marketplace.controllers.user.UserRequest;
import com.uade.tpo.marketplace.entity.User;
import com.uade.tpo.marketplace.exceptions.UserNotFoundException;
import com.uade.tpo.marketplace.repository.UserRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User getUserById(long userId)
        throws UserNotFoundException {
        return userRepository.findById(userId).orElseThrow(
                () -> new UserNotFoundException()
        );
    }

    @Override
    public User updateUser(UserRequest userRequest) throws UserNotFoundException {
        // Validar que el usuario exista por email
        User user = userRepository.findByEmail(userRequest.getEmail()).orElseThrow(
                () -> new UserNotFoundException()
        );

        user.setEmail(userRequest.getEmail());
        user.setPassword(userRequest.getPassword());
        user.setFirstname(userRequest.getFirstName());
        user.setLastname(userRequest.getLastName());
        user.setRole(userRequest.getRole());

        return userRepository.save(user);
    }

    @Override
    public void deleteUser(long userId) {
        userRepository.deleteById(userId);
    }

    @Override
    public User getUserByEmail(String email) throws UserNotFoundException {
        User user = userRepository.findByEmail(email).orElseThrow(
                () -> new UserNotFoundException()
        );
        return user;
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

}
