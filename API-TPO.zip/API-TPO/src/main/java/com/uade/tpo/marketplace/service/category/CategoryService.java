package com.uade.tpo.marketplace.service.category;

import java.util.Optional;
import com.uade.tpo.marketplace.controllers.category.CreateCategoryRequest;
import com.uade.tpo.marketplace.exceptions.CategoryNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import com.uade.tpo.marketplace.entity.Category;
import com.uade.tpo.marketplace.exceptions.CategoryDuplicateException;

public interface CategoryService {

    Page<Category> getCategories(PageRequest pageRequest);

    Optional<Category> getCategoryById(Long categoryId);

    Optional<Category> getCategoryByName(String name);

    Category createCategory(CreateCategoryRequest request) throws CategoryDuplicateException;

    void deleteCategory(long categoryId) throws CategoryNotFoundException;

}