package com.uade.tpo.marketplace.controllers.order;

import lombok.Data;

@Data
public class OrderItemRequest {

    private long productId;

    private int quantity;

}
