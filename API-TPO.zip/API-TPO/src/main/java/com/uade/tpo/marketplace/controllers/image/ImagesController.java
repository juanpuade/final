package com.uade.tpo.marketplace.controllers.image;

import com.uade.tpo.marketplace.entity.Image;
import com.uade.tpo.marketplace.entity.Product;
import com.uade.tpo.marketplace.exceptions.ProductNotFoundException;
import com.uade.tpo.marketplace.service.image.ImageService;
import com.uade.tpo.marketplace.service.product.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.sql.rowset.serial.SerialBlob;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Base64;

@RestController
@RequestMapping("/images")
public class ImagesController {

    @Autowired
    private ImageService imageService;

    @Autowired
    private ProductService productService;

    
    @GetMapping
    @Operation(summary = "Obtener imagen de un producto")
    public ResponseEntity<ImageResponse> getImage(
            @RequestParam(required = false) Long id,
            @RequestParam long productId) throws SQLException {

        Image image;

        if (id != null) {
            image = imageService.viewById(id);
        } else {
            image = imageService.getImageForProduct(productId);
        }

        if (image == null || image.getImage() == null) {
            ImageResponse empty = ImageResponse.builder()
                    .id(null)
                    .file(null)
                    .build();
            return ResponseEntity.ok(empty);
        }

        Blob blob = image.getImage();
        byte[] bytes = blob.getBytes(1, (int) blob.length());
        String base64 = Base64.getEncoder().encodeToString(bytes);

        ImageResponse response = ImageResponse.builder()
                .id(image.getId())
                .file(base64)
                .build();

        return ResponseEntity.ok(response);
    }

    @PostMapping
    @PreAuthorize("hasRole('SELLER')")
    @Operation(summary = "Cargar imagen para un producto")
    public ResponseEntity<ImageResponse> addImagePost(
            @ModelAttribute AddFileRequest request)
            throws IOException, SQLException, ProductNotFoundException {

        byte[] bytes = request.getFile().getBytes();
        long productId = request.getProductId();

        Product product = productService.addImage(productId);

        Blob blob = new SerialBlob(bytes);
        Image image = Image.builder()
                .image(blob)
                .productId(product)
                .build();

        Image saved = imageService.create(image);

        String base64 = Base64.getEncoder().encodeToString(bytes);

        ImageResponse response = ImageResponse.builder()
                .id(saved.getId())
                .file(base64)
                .build();

        return ResponseEntity.ok(response);
    }
}
