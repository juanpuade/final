package com.uade.tpo.marketplace.controllers.cart;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("carts")
public class CartController {

    // El carrito de compras se realizara en el frontend

    /**
     * Requisito: Gestión del carrito de compras, con la posibilidad de agregar, eliminar o
     * modificar productos.
    */

    // Implementar POST addToCart({userId}, {productId}, {quantity}) agregar producto al carrito

    // Implementar DELETE removeFromCart({userId}, {productId}) eliminar producto del carrito

    // Implementar GET getCart({userId}) obtener el carrito del usuario

    /**
     * Realizar el checkout del carrito con el correspondiente cálculo automático del
     * total de la compra.
     * Una vez realizado el checkout (sin procesamiento de pago), se descontará el
     * stock de dicho producto. Se deberá validar si cuenta con el stock
     * correspondiente.
     */

    // Implementar POST checkout({userId}) realizar el checkout del carrito

}
