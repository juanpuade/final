package com.uade.tpo.marketplace.controllers.user;
import java.util.List;
import com.uade.tpo.marketplace.entity.User;
import com.uade.tpo.marketplace.exceptions.UserNotFoundException;
import com.uade.tpo.marketplace.service.user.UserService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    @PreAuthorize("hasRole('SELLER')")
    @Operation(summary = "Listar todos los usuarios")
    public ResponseEntity<List<User>> getAllUsers(){
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @PutMapping
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Actualizar un usuario")
    ResponseEntity<User> updateUser(@RequestBody UserRequest userRequest)
            throws UserNotFoundException {
        User updatedUser = userService.updateUser(userRequest);
        if (updatedUser != null)
            return ResponseEntity.ok(updatedUser);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{userId}")
    @PreAuthorize("hasRole('SELLER')")
    @Operation(
            summary = "Eliminar un usuario")
    ResponseEntity<Void> deleteUser(@PathVariable long userId) {
        userService.deleteUser(userId);
        return ResponseEntity.noContent().build();
    }

}
