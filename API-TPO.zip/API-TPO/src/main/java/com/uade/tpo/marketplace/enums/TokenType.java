package com.uade.tpo.marketplace.enums;

public enum TokenType {

    BEARER

}
