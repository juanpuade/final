import { useState } from 'react';
import styles from './StockForm.module.css';

const StockForm = () => {
  const [formData, setFormData] = useState({
    furnitureType: '',
    productName: '',
    price: '',
    quantity: '',
    productDetails: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Stock data:', formData);
    // Aquí iría la lógica para guardar el stock
  };

  const handleImageUpload = (e) => {
    const files = e.target.files;
    console.log('Uploading images:', files);
    // Aquí iría la lógica para subir imágenes
  };

  return (
    <div className={styles.manageStockContainer}>
      <h1 className={styles.title}>Manage Stock</h1>
      
      <form onSubmit={handleSubmit} className={styles.form}>
        <div className={styles.formGroup}>
          <label htmlFor="furnitureType" className={styles.label}>Furniture Type</label>
          <select
            id="furnitureType"
            name="furnitureType"
            value={formData.furnitureType}
            onChange={handleChange}
            className={styles.select}
          >
            <option value="">Select Type</option>
            <option value="chair">Chair</option>
            <option value="table">Table</option>
            <option value="wardrobe">Wardrobe</option>
            <option value="shelf">Shelf</option>
          </select>
        </div>
        
        <div className={styles.formGroup}>
          <label htmlFor="productName" className={styles.label}>Product Name</label>
          <input
            type="text"
            id="productName"
            name="productName"
            value={formData.productName}
            onChange={handleChange}
            placeholder="Enter Product Name"
            className={styles.input}
          />
        </div>
        
        <div className={styles.formGroup}>
          <label htmlFor="price" className={styles.label}>Price</label>
          <input
            type="text"
            id="price"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Enter Price"
            className={styles.input}
          />
        </div>
        
        <div className={styles.formGroup}>
          <label htmlFor="quantity" className={styles.label}>Quantity</label>
          <input
            type="number"
            id="quantity"
            name="quantity"
            value={formData.quantity}
            onChange={handleChange}
            placeholder="Enter Quantity"
            className={styles.input}
          />
        </div>
        
        <div className={styles.formGroup}>
          <label htmlFor="productDetails" className={styles.label}>Product Details</label>
          <textarea
            id="productDetails"
            name="productDetails"
            value={formData.productDetails}
            onChange={handleChange}
            placeholder="Enter Product Details"
            className={styles.textarea}
            rows="4"
          />
        </div>
        
        <div className={styles.imageUploadSection}>
          <h3 className={styles.uploadTitle}>Upload Product Images</h3>
          <div className={styles.uploadArea}>
            <p className={styles.uploadText}>Drag and drop or click to upload</p>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageUpload}
              className={styles.fileInput}
            />
            <button type="button" className={styles.uploadButton}>Upload</button>
          </div>
        </div>
        
        <div className={styles.buttonGroup}>
          <button type="button" className={styles.updateButton}>Update</button>
          <button type="submit" className={styles.addButton}>Add</button>
        </div>
      </form>
    </div>
  );
};

export default StockForm;
