import Link from 'next/link';
import { useRouter } from 'next/router';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../../Redux/authSlice';
import styles from './Header.module.css';

const Header = () => {
  const router = useRouter();
  const dispatch = useDispatch();

  const { isAuthenticated, user } = useSelector((state) => state.auth);

  // Total de productos en el carrito desde Redux
  const totalItems = useSelector((state) =>
    state.cart.cartItems.reduce((acc, item) => acc + item.quantity, 0)
  );

  // Rol tomado DIRECTO de Redux
  const userRole = user?.role || 'USER';

  // Ocultar logout en rutas de administración
  const hideLogout = ['/stock', '/admin-users', '/categories'].some(
    (path) => router.pathname.startsWith(path)
  );

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <div className={styles.logo}>
          <Link href="/">FURNISH</Link>
        </div>

        <nav className={styles.nav}>
          <Link href="/" className={styles.navLink}>Inicio</Link>
          <Link href="/products" className={styles.navLink}>Productos</Link>

          {userRole === 'SELLER' && (
            <>
              <Link href="/stock" className={styles.navLink}>Adm. Productos</Link>
              <Link href="/admin-users" className={styles.navLink}>Adm. Usuarios</Link>
            </>
          )}

          {userRole === 'USER' && (
            <Link href="/orders" className={styles.navLink}>Mis Órdenes</Link>
          )}
        </nav>

        <div className={styles.actions}>
          <div className={styles.icons}>
            <Link href="/cart" className={styles.cartButton}>
              <span className={styles.cartIcon}>Carrito</span>
              {totalItems > 0 && (
                <span className={styles.cartCount}>{totalItems}</span>
              )}
            </Link>

            {isAuthenticated ? (
              <div className={styles.userMenu}>
                <div
                  className={styles.userRoleLabel}
                  title={`${userRole === 'SELLER' ? 'Vendedor' : 'Usuario'}: ${user?.name || user?.email}`}
                >
                  {userRole === 'SELLER' ? 'Vendedor' : 'Usuario'}
                </div>

                {!hideLogout && (
                  <button
                    onClick={() => dispatch(logout())}
                    className={styles.logoutButton}
                    title="Cerrar Sesión"
                  >
                    Cerrar Sesión
                  </button>
                )}
              </div>
            ) : (
              <Link href="/login" className={styles.profileLink}>
                <button className={styles.iconButton}>Iniciar Sesión</button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
