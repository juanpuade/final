import Link from 'next/link';
import styles from './ProductCard.module.css';
import { useDispatch } from "react-redux";
import { addToCart } from "../../Redux/cartSlice";

const ProductCard = ({ product }) => {
  const dispatch = useDispatch();

  const calculateDiscountedPrice = (price, discount) => {
    if (!discount || discount === 0) return null;
    const numericPrice = typeof price === 'string'
      ? parseFloat(price.replace('$', ''))
      : price;
    return numericPrice * (1 - discount / 100);
  };

  const formatPrice = (price) => {
    if (typeof price === 'string') return price;
    return `$${price.toFixed(2)}`;
  };

  const hasDiscount = product.discount && product.discount > 0;
  const discountedPrice = hasDiscount
    ? calculateDiscountedPrice(product.price, product.discount)
    : null;

  return (
    <div className={styles.productCard}>
      <Link href={`/product/${product.id}`} className={styles.productLink}>
        <div className={styles.productImage}>
          <img 
            src={product.image || '/placeholder-product.jpg'} 
            alt={product.name}
            onError={(e) => {
              e.target.src = '/placeholder-product.jpg';
            }}
          />
        </div>
        <div className={styles.productInfo}>
          <h3 className={styles.productName}>{product.name}</h3>
          <div className={styles.priceContainer}>
            {hasDiscount ? (
              <>
                <span className={styles.originalPrice}>{formatPrice(product.price)}</span>
                <div className={styles.discountedPriceContainer}>
                  <span className={styles.discountedPrice}>
                    {formatPrice(discountedPrice)}
                  </span>
                  <span className={styles.discountPercentage}>
                    -{product.discount}%
                  </span>
                </div>
              </>
            ) : (
              <span className={styles.regularPrice}>
                {formatPrice(product.price)}
              </span>
            )}
          </div>
        </div>
      </Link>

      <button
        className={styles.addButton}
        onClick={() => dispatch(addToCart(product))}
      >
        Agregar al carrito
      </button>
    </div>
  );
};

export default ProductCard;
