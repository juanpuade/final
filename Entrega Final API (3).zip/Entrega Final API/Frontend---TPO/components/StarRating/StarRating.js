import styles from './StarRating.module.css';

const StarRating = ({ rating = 0, maxStars = 5, size = 'medium' }) => {
  const stars = [];
  const numericRating = parseFloat(rating) || 0;
  
  // Debug: Log del rating recibido
  console.log('StarRating recibido:', rating, 'Numeric:', numericRating);
  
  for (let i = 1; i <= maxStars; i++) {
    const isFilled = i <= numericRating;
    stars.push(
      <span
        key={i}
        className={`${styles.star} ${isFilled ? styles.filled : styles.empty} ${styles[size]}`}
      >
        ★
      </span>
    );
  }

  return (
    <div className={styles.starRating}>
      {stars}
    </div>
  );
};

export default StarRating;
