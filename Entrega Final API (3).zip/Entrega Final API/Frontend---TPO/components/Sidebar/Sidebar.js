import { useState, useEffect } from 'react';
import styles from './Sidebar.module.css';

const Sidebar = ({ filters, onFilterChange, onApplyFilters }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleFilterChange = (filterType, value) => {
    onFilterChange(filterType, value);
  };

  const handleApplyFilters = () => {
    onApplyFilters();
    if (isMobile) {
      setIsOpen(false);
    }
  };

  const handleClearFilters = () => {
    onFilterChange('category', '');
    onFilterChange('price', '');
    onFilterChange('color', '');
    onFilterChange('size', '');
  };

  return (
    <>
      {isMobile && (
        <button className={styles.toggleButton} onClick={toggleSidebar}>
          Filtros
        </button>
      )}
      
      <div className={`${styles.sidebar} ${isMobile ? (isOpen ? styles.open : '') : styles.desktop}`}>
        <div className={styles.sidebarContent}>
          {isMobile && (
            <div className={styles.header}>
              <h3>Filtros</h3>
              <button className={styles.closeButton} onClick={toggleSidebar}>
                Cerrar
              </button>
            </div>
          )}
          
          <div className={styles.filters}>
            <div className={styles.filterGroup}>
              <label className={styles.label}>Categoría</label>
              <select 
                value={filters.category} 
                onChange={(e) => handleFilterChange('category', e.target.value)}
                className={styles.select}
              >
                <option value="">Todas las categorías</option>
                <option value="furniture">Muebles</option>
                <option value="storage">Almacenamiento</option>
                <option value="tables">Mesas</option>
                <option value="chairs">Sillas</option>
                <option value="decor">Decoración</option>
              </select>
            </div>
            
            <div className={styles.filterGroup}>
              <label className={styles.label}>Precio</label>
              <select 
                value={filters.price} 
                onChange={(e) => handleFilterChange('price', e.target.value)}
                className={styles.select}
              >
                <option value="">Todos los precios</option>
                <option value="0-100">$0 - $100</option>
                <option value="100-200">$100 - $200</option>
                <option value="200-300">$200 - $300</option>
                <option value="300-500">$300 - $500</option>
                <option value="500+">$500+</option>
              </select>
            </div>
            
            <div className={styles.filterGroup}>
              <label className={styles.label}>Color</label>
              <select 
                value={filters.color} 
                onChange={(e) => handleFilterChange('color', e.target.value)}
                className={styles.select}
              >
                <option value="">Todos los colores</option>
                <option value="light">Madera Clara</option>
                <option value="dark">Madera Oscura</option>
                <option value="white">Blanco</option>
                <option value="black">Negro</option>
                <option value="gray">Gris</option>
              </select>
            </div>
            
            <div className={styles.filterGroup}>
              <label className={styles.label}>Tamaño</label>
              <select 
                value={filters.size} 
                onChange={(e) => handleFilterChange('size', e.target.value)}
                className={styles.select}
              >
                <option value="">Todos los tamaños</option>
                <option value="small">Pequeño</option>
                <option value="medium">Mediano</option>
                <option value="large">Grande</option>
              </select>
            </div>
          </div>
          
          <div className={styles.actions}>
            <button className={styles.applyButton} onClick={handleApplyFilters}>
              Aplicar Filtros
            </button>
            <button className={styles.clearButton} onClick={handleClearFilters}>
              Limpiar
            </button>
          </div>
        </div>
      </div>
      
      {isMobile && isOpen && <div className={styles.overlay} onClick={toggleSidebar}></div>}
    </>
  );
};

export default Sidebar;
