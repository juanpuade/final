import styles from './Footer.module.css';
import Link from 'next/link';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.footerUp}>
          <h3>Habitaré</h3>
          <p>Diseño que transforma tu espacio.</p>
        </div>

        <div className={styles.footerContainer}>
          {/* Tienda */}
          <div className={styles.footerColumn}>
            <h3>Tienda</h3>
            <Link href="/products">
              Armarios
            </Link>
            <Link href="/products">
              Estantes
            </Link>
            <Link href="/products">
              Comodas
            </Link>
            <Link href="/products">
              Mesas
            </Link>
          </div>

          {/* Ayuda */}
          <div className={styles.footerColumn}> 
            <h3>Ayuda</h3>
            <Link href="/ayuda">Contacto</Link>
            <Link href="/ayuda">FAQ</Link>
            <Link href="/ayuda">Envíos y Devoluciones</Link>
          </div>

          {/* Redes Sociales */}
          <div className={styles.footerColumn}>
            <h3>Síguenos</h3>
            <div className={styles.socials}>
              <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">IG</a>
              <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">FB</a>
              <a href="https://www.pinterest.com" target="_blank" rel="noopener noreferrer">PI</a>
            </div>
          </div>
        </div>

        <div className={styles.footerBottom}>
          © 2025 Habitaré. Todos los derechos reservados.
        </div>

        {/* Redes Sociales */}
        <div className={styles.footerColumn}>
          <h3>Síguenos</h3>
          <div className={styles.socials}>
            <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">IG</a>
            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">FB</a>
            <a href="https://www.pinterest.com" target="_blank" rel="noopener noreferrer">PI</a>
          </div>
        </div>
      </div>

      <div className={styles.footerBottom}>
        © 2025 Habitaré. Todos los derechos reservados.
      </div>
    </footer>
  );
};

export default Footer;
