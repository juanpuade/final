import styles from './HorizontalFilters.module.css';

const HorizontalFilters = ({ filters, onFilterChange, onApplyFilters, searchTerm, onSearchChange, categories = [] }) => {
  const handleFilterChange = (filterType, value) => {
    onFilterChange(filterType, value);
  };

  const handleClearFilters = () => {
    onFilterChange('category', '');
    onFilterChange('rating', '');
    onFilterChange('priceFrom', '');
    onFilterChange('priceTo', '');
    onFilterChange('hasDiscount', false);
    onFilterChange('sortOrder', '');
    onSearchChange('');
  };
  
  const handleDiscountToggle = () => {
    onFilterChange('hasDiscount', !filters.hasDiscount);
  };

  const handleSearchChange = (e) => {
    onSearchChange(e.target.value);
  };

  const handleSearch = () => {
    // La búsqueda se maneja automáticamente con el onChange
  };

  const handleClearSearch = () => {
    onSearchChange('');
  };

  return (
    <div className={styles.filtersContainer}>
      <h2 className={styles.filtersTitle}>Filtros</h2>
      <div className={styles.filtersRow}>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Categoría</label>
          <select 
            value={filters.category} 
            onChange={(e) => handleFilterChange('category', e.target.value)}
            className={styles.filterSelect}
          >
            <option value="">Todas las Categorías</option>
            {categories.map((category) => (
              <option key={category.id} value={category.name}>
                {category.name}
              </option>
            ))}
          </select>
        </div>
        
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Precio Desde</label>
          <input
            type="number"
            placeholder="0"
            value={filters.priceFrom || ''}
            onChange={(e) => handleFilterChange('priceFrom', e.target.value)}
            className={styles.priceInput}
            min="0"
            step="0.01"
          />
        </div>
        
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Precio Hasta</label>
          <input
            type="number"
            placeholder="Sin límite"
            value={filters.priceTo || ''}
            onChange={(e) => handleFilterChange('priceTo', e.target.value)}
            className={styles.priceInput}
            min="0"
            step="0.01"
          />
        </div>
        
        <div className={styles.searchGroup}>
          <label className={styles.filterLabel}>Buscar por Nombre</label>
          <input
            type="text"
            placeholder="Nombre del producto"
            value={searchTerm}
            onChange={handleSearchChange}
            className={styles.searchInput}
          />
          {searchTerm && (
            <button 
              onClick={handleClearSearch}
              className={styles.clearSearchButton}
            >
              Limpiar
            </button>
          )}
        </div>
        
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Ordenar por</label>
          <select 
            value={filters.sortOrder || ''} 
            onChange={(e) => handleFilterChange('sortOrder', e.target.value)}
            className={styles.filterSelect}
          >
            <option value="">Sin ordenar</option>
            <option value="priceAsc">Menor Precio</option>
            <option value="priceDesc">Mayor Precio</option>
          </select>
        </div>
        
        <div className={styles.filterGroup}>
          <button
            onClick={handleDiscountToggle}
            className={`${styles.discountButton} ${filters.hasDiscount ? styles.discountButtonActive : ''}`}
          >
            {filters.hasDiscount ? '✓ Con Descuento' : 'Con Descuento'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default HorizontalFilters;
