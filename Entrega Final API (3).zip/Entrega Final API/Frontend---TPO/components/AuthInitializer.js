import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { initAuth } from "../redux/authSlice";

// Componente que inicializa la autenticación una sola vez al cargar la app
const AuthInitializer = ({ children }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(initAuth());
  }, [dispatch]);

  return <>{children}</>;
};

export default AuthInitializer;

