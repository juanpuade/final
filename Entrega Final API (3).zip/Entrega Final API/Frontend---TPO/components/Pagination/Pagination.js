import styles from './Pagination.module.css';

const Pagination = ({ 
  currentPage, 
  totalPages, 
  onPageChange, 
  hasNextPage, 
  hasPreviousPage,
  loading = false 
}) => {
  // Generar array de páginas para mostrar
  const getPageNumbers = () => {
    const pages = [];
    const maxVisiblePages = 5;
    
    if (totalPages <= maxVisiblePages) {
      // Si hay pocas páginas, mostrar todas
      for (let i = 0; i < totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Lógica para mostrar páginas con elipsis
      const startPage = Math.max(0, currentPage - 2);
      const endPage = Math.min(totalPages - 1, startPage + maxVisiblePages - 1);
      
      if (startPage > 0) {
        pages.push(0);
        if (startPage > 1) {
          pages.push('...');
        }
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
      
      if (endPage < totalPages - 1) {
        if (endPage < totalPages - 2) {
          pages.push('...');
        }
        pages.push(totalPages - 1);
      }
    }
    
    return pages;
  };

  const pageNumbers = getPageNumbers();

  if (totalPages <= 1) {
    return null; // No mostrar paginación si hay una página o menos
  }

  return (
    <div className={styles.paginationContainer}>
      <div className={styles.paginationInfo}>
        <span className={styles.pageInfo}>
          Página {currentPage + 1} de {totalPages}
        </span>
      </div>
      
      <div className={styles.paginationControls}>
        {/* Botón Anterior */}
        <button
          className={`${styles.paginationButton} ${styles.prevButton}`}
          onClick={() => onPageChange(currentPage - 1)}
          disabled={!hasPreviousPage || loading}
          aria-label="Página anterior"
        >
          ← Anterior
        </button>

        {/* Números de página */}
        <div className={styles.pageNumbers}>
          {pageNumbers.map((page, index) => (
            <button
              key={index}
              className={`${styles.pageButton} ${
                page === currentPage ? styles.activePage : ''
              } ${page === '...' ? styles.ellipsis : ''}`}
              onClick={() => typeof page === 'number' && onPageChange(page)}
              disabled={page === '...' || loading}
              aria-label={page === '...' ? 'Más páginas' : `Página ${page + 1}`}
            >
              {page === '...' ? '...' : page + 1}
            </button>
          ))}
        </div>

        {/* Botón Siguiente */}
        <button
          className={`${styles.paginationButton} ${styles.nextButton}`}
          onClick={() => onPageChange(currentPage + 1)}
          disabled={!hasNextPage || loading}
          aria-label="Página siguiente"
        >
          Siguiente →
        </button>
      </div>
    </div>
  );
};

export default Pagination;
