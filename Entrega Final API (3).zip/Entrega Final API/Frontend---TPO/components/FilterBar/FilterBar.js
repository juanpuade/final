import styles from './FilterBar.module.css';

const FilterBar = ({ filters, onFilterChange }) => {
  return (
    <div className={styles.filters}>
      <select 
        value={filters.category} 
        onChange={(e) => onFilterChange('category', e.target.value)}
        className={styles.filterSelect}
      >
        <option value="">Category</option>
        <option value="furniture">Furniture</option>
        <option value="storage">Storage</option>
        <option value="tables">Tables</option>
      </select>
      
      <select 
        value={filters.price} 
        onChange={(e) => onFilterChange('price', e.target.value)}
        className={styles.filterSelect}
      >
        <option value="">Price</option>
        <option value="0-100">$0 - $100</option>
        <option value="100-200">$100 - $200</option>
        <option value="200-300">$200 - $300</option>
        <option value="300+">$300+</option>
      </select>
      
      <select 
        value={filters.color} 
        onChange={(e) => onFilterChange('color', e.target.value)}
        className={styles.filterSelect}
      >
        <option value="">Color</option>
        <option value="light">Light Wood</option>
        <option value="dark">Dark Wood</option>
        <option value="white">White</option>
      </select>
      
      <select 
        value={filters.size} 
        onChange={(e) => onFilterChange('size', e.target.value)}
        className={styles.filterSelect}
      >
        <option value="">Size</option>
        <option value="small">Small</option>
        <option value="medium">Medium</option>
        <option value="large">Large</option>
      </select>
    </div>
  );
};

export default FilterBar;
