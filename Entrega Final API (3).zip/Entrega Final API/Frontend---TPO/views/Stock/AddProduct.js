import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Swal from 'sweetalert2';
import { fetchCategories, createProduct, uploadProductImage } from '../../redux/productsSlice';
import styles from './AddProduct.module.css';

const AddProduct = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { categories } = useSelector((state) => state.products);
  
  const [formData, setFormData] = useState({
    name: '',
    stock: 0,
    description: '',
    price: '',
    discount: 0,
    category: null
  });
  const [images, setImages] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);

  useEffect(() => {
    dispatch(fetchCategories());
  }, [dispatch]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'category') {
      const selectedCategory = categories.find(cat => cat.id === parseInt(value));
      setFormData(prev => ({
        ...prev,
        category: selectedCategory || null
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
    
    setError('');
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const newImages = files.map(file => ({
      id: Date.now() + Math.random(),
      file: file,
      preview: URL.createObjectURL(file)
    }));
    setImages(prev => [...prev, ...newImages]);
  };

  const handleImageDelete = async (imageId) => {
    const imageToDelete = images.find(img => img.id === imageId);
    const imageName = imageToDelete?.file?.name || 'esta imagen';

    const result = await Swal.fire({
      icon: 'warning',
      title: '¿Estás seguro?',
      text: `¿Deseas eliminar ${imageName}?`,
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#6b5d4a',
      cancelButtonColor: '#6b5d4a'
    });

    if (result.isConfirmed) {
      setImages(prev => prev.filter(img => img.id !== imageId));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.price || !formData.description) {
      setError('Por favor completa los campos obligatorios');
      return;
    }

    if (!formData.category) {
      setError('Por favor selecciona una categoría');
      return;
    }

    try {
      setLoading(true);
      setError('');

      const productData = {
        name: formData.name,
        stock: parseInt(formData.stock) || 0,
        description: formData.description,
        price: parseFloat(formData.price),
        discount: parseInt(formData.discount) || 0,
        categoryName: formData.category.name
      };

      const result = await dispatch(createProduct(productData));

      if (createProduct.fulfilled.match(result)) {
        const newProduct = result.payload;
        
        // Subir imágenes si hay alguna
        if (images.length > 0) {
          setUploadingImages(true);
          const uploadPromises = images.map(image => 
            dispatch(uploadProductImage({ file: image.file, productId: newProduct.id }))
          );
          await Promise.all(uploadPromises);
          setUploadingImages(false);
        }
        
        Swal.fire({
          icon: 'success',
          title: 'Éxito',
          text: 'Producto creado exitosamente',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        }).then(() => {
          router.push('/stock');
        });
      } else {
        throw new Error(result.error?.message || 'Error al crear producto');
      }
    } catch (err) {
      console.error('Error al crear producto:', err);
      setError(`Error al crear producto: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <Link href="/stock" className={styles.backButton}>
          Volver a Stock
        </Link>
        <h1 className={styles.title}>Agregar Nuevo Producto</h1>
      </div>

      {error && (
        <div className={styles.errorMessage}>
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className={styles.form}>
        <div className={styles.formGrid}>
          <div className={styles.formSection}>
            <h3 className={styles.sectionTitle}>Información Básica</h3>
            
            <div className={styles.inputGroup}>
              <label htmlFor="name" className={styles.label}>Nombre del Producto *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className={styles.input}
                placeholder="Ej: Mesa de Centro Moderna"
                required
              />
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="price" className={styles.label}>Precio *</label>
              <input
                type="number"
                id="price"
                name="price"
                value={formData.price}
                onChange={handleInputChange}
                className={styles.input}
                min="0"
                step="0.01"
                placeholder="11000.0"
                required
              />
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="description" className={styles.label}>Descripción *</label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                className={styles.textarea}
                placeholder="Describe las características del producto..."
                rows="4"
                required
              />
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="category" className={styles.label}>Categoría</label>
              <select
                id="category"
                name="category"
                value={formData.category?.id || ''}
                onChange={handleInputChange}
                className={styles.select}
              >
                <option value="">Seleccionar categoría</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className={styles.formSection}>
            <h3 className={styles.sectionTitle}>Stock y Descuento</h3>
            
            <div className={styles.inputGroup}>
              <label htmlFor="stock" className={styles.label}>Stock Inicial</label>
              <input
                type="number"
                id="stock"
                name="stock"
                value={formData.stock}
                onChange={handleInputChange}
                className={styles.input}
                min="0"
                placeholder="25"
              />
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="discount" className={styles.label}>Descuento (%)</label>
              <input
                type="number"
                id="discount"
                name="discount"
                value={formData.discount}
                onChange={handleInputChange}
                className={styles.input}
                min="0"
                max="100"
                placeholder="6"
              />
            </div>
          </div>
        </div>

        <div className={styles.imageSection}>
          <h3 className={styles.sectionTitle}>Imágenes del Producto</h3>
          
          <div className={styles.imageUpload}>
            <input
              type="file"
              id="imageUpload"
              multiple
              accept="image/*"
              onChange={handleImageUpload}
              className={styles.fileInput}
            />
            <label htmlFor="imageUpload" className={styles.uploadButton}>
              Subir Imágenes
            </label>
          </div>

          {images.length > 0 && (
            <div className={styles.imagePreview}>
              <h4>Imágenes seleccionadas:</h4>
              <div className={styles.imageGrid}>
                {images.map(image => (
                  <div key={image.id} className={styles.imageItem}>
                    <img src={image.preview} alt="Preview" className={styles.previewImage} />
                    <button
                      type="button"
                      onClick={() => handleImageDelete(image.id)}
                      className={styles.deleteImageButton}
                    >
                      Eliminar
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className={styles.formActions}>
          <Link href="/stock" className={styles.cancelButton}>
            Cancelar
          </Link>
          <button 
            type="submit" 
            className={styles.submitButton}
            disabled={loading || uploadingImages}
          >
            {loading ? 'Creando Producto...' : 
             uploadingImages ? 'Subiendo Imágenes...' : 
             'Crear Producto'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddProduct;
