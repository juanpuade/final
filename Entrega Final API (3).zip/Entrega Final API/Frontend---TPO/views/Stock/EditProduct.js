import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Swal from 'sweetalert2';
import { 
  fetchProductById, 
  fetchCategories, 
  updateStock, 
  updateDiscount, 
  uploadProductImage,
  clearSelectedProduct 
} from '../../redux/productsSlice';
import styles from './EditProduct.module.css';

const EditProduct = ({ productId }) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { selectedProduct, categories, loading } = useSelector((state) => state.products);
  
  const [formData, setFormData] = useState({
    name: '',
    stock: 0,
    description: '',
    price: '',
    discount: 0,
    category: null
  });
  const [existingImages, setExistingImages] = useState([]);
  const [newImages, setNewImages] = useState([]);
  const [error, setError] = useState('');
  const [originalStock, setOriginalStock] = useState(0);
  const [originalDiscount, setOriginalDiscount] = useState(0);
  const [stockChanged, setStockChanged] = useState(false);
  const [discountChanged, setDiscountChanged] = useState(false);
  const [savingStock, setSavingStock] = useState(false);
  const [savingDiscount, setSavingDiscount] = useState(false);
  const [savingImages, setSavingImages] = useState(false);

  useEffect(() => {
    if (productId) {
      dispatch(fetchProductById(productId));
      dispatch(fetchCategories());
    }
    return () => {
      dispatch(clearSelectedProduct());
    };
  }, [dispatch, productId]);

  useEffect(() => {
    if (selectedProduct) {
      setFormData({
        name: selectedProduct.name || '',
        stock: selectedProduct.stock || 0,
        description: selectedProduct.description || '',
        price: selectedProduct.price || '',
        discount: selectedProduct.discount || 0,
        category: selectedProduct.category || null
      });
      setOriginalStock(selectedProduct.stock || 0);
      setOriginalDiscount(selectedProduct.discount || 0);
      
      if (selectedProduct.image) {
        setExistingImages([{
          id: Date.now(),
          url: selectedProduct.image,
          isExisting: true
        }]);
      }
    }
  }, [selectedProduct]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'category') {
      const selectedCategory = categories.find(cat => cat.id === parseInt(value));
      setFormData(prev => ({
        ...prev,
        category: selectedCategory || null
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
    
    setError('');
    
    if (name === 'stock') {
      setStockChanged(parseInt(value) !== originalStock);
    } else if (name === 'discount') {
      setDiscountChanged(parseInt(value) !== originalDiscount);
    }
  };

  const handleNewImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const validFiles = [];
    const invalidFiles = [];

    files.forEach(file => {
      if (file.type !== 'image/png') {
        invalidFiles.push(`${file.name}: No es un archivo PNG`);
        return;
      }
      if (file.size > 1048576) {
        invalidFiles.push(`${file.name}: Excede el tamaño máximo de 1MB`);
        return;
      }
      validFiles.push(file);
    });

    if (invalidFiles.length > 0) {
      Swal.fire({
        icon: 'error',
        title: 'Archivos inválidos',
        html: `Los siguientes archivos no cumplen los requisitos:<br>${invalidFiles.join('<br>')}`,
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    }

    if (validFiles.length > 0) {
      const newImageFiles = validFiles.map(file => ({
        id: Date.now() + Math.random(),
        file: file,
        preview: URL.createObjectURL(file),
        isNew: true
      }));
      setNewImages(prev => [...prev, ...newImageFiles]);
    }
  };

  const handleNewImageDelete = async (imageId) => {
    const result = await Swal.fire({
      icon: 'warning',
      title: '¿Estás seguro?',
      text: '¿Deseas eliminar esta imagen?',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#6b5d4a',
      cancelButtonColor: '#6b5d4a'
    });

    if (result.isConfirmed) {
      setNewImages(prev => prev.filter(img => img.id !== imageId));
    }
  };

  const uploadNewImages = async () => {
    if (newImages.length === 0) return;

    try {
      setSavingImages(true);
      const uploadPromises = newImages.map(image =>
        dispatch(uploadProductImage({ file: image.file, productId }))
      );

      const results = await Promise.all(uploadPromises);
      const successfulUploads = results.filter(r => uploadProductImage.fulfilled.match(r));
      
      if (successfulUploads.length > 0) {
        setNewImages([]);
        dispatch(fetchProductById(productId));
        Swal.fire({
          icon: 'success',
          title: 'Éxito',
          text: 'Imágenes guardadas exitosamente',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Error al subir las imágenes',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      }
    } catch (error) {
      console.error('Error uploading images:', error);
    } finally {
      setSavingImages(false);
    }
  };

  const handleSaveStock = async () => {
    setSavingStock(true);
    try {
      const result = await dispatch(updateStock({ productId, stock: parseInt(formData.stock) }));
      
      if (updateStock.fulfilled.match(result)) {
        setOriginalStock(formData.stock);
        setStockChanged(false);
        Swal.fire({
          icon: 'success',
          title: 'Éxito',
          text: 'Stock actualizado exitosamente',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      } else {
        throw new Error('Error al actualizar');
      }
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Error al actualizar el stock',
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    } finally {
      setSavingStock(false);
    }
  };

  const handleSaveDiscount = async () => {
    setSavingDiscount(true);
    try {
      const result = await dispatch(updateDiscount({ productId, discount: parseInt(formData.discount) }));
      
      if (updateDiscount.fulfilled.match(result)) {
        setOriginalDiscount(formData.discount);
        setDiscountChanged(false);
        Swal.fire({
          icon: 'success',
          title: 'Éxito',
          text: 'Descuento actualizado exitosamente',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      } else {
        throw new Error('Error al actualizar');
      }
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Error al actualizar el descuento',
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    } finally {
      setSavingDiscount(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.price || !formData.description) {
      setError('Por favor completa los campos obligatorios');
      return;
    }

    Swal.fire({
      icon: 'success',
      title: 'Éxito',
      text: 'Producto actualizado exitosamente',
      confirmButtonText: 'Aceptar',
      confirmButtonColor: '#6b5d4a'
    }).then(() => {
      router.push('/stock');
    });
  };

  if (loading) {
    return (
      <div className={styles.container}>
        <div className={styles.loading}>
          <h2>Cargando producto...</h2>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <Link href="/stock" className={styles.backButton}>
          Volver a Stock
        </Link>
        <h1 className={styles.title}>Editar Producto</h1>
      </div>

      {error && (
        <div className={styles.errorMessage}>
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className={styles.form}>
        <div className={styles.formGrid}>
          <div className={styles.formSection}>
            <h3 className={styles.sectionTitle}>Información del Producto</h3>
            
            <div className={styles.inputGroup}>
              <label htmlFor="name" className={styles.label}>Nombre del Producto *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className={styles.input}
                required
              />
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="description" className={styles.label}>Descripción *</label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                className={styles.textarea}
                rows="4"
                required
              />
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="price" className={styles.label}>Precio *</label>
              <input
                type="number"
                id="price"
                name="price"
                value={formData.price}
                onChange={handleInputChange}
                className={styles.input}
                min="0"
                step="0.01"
                required
              />
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="category" className={styles.label}>Categoría</label>
              <select
                id="category"
                name="category"
                value={formData.category?.id || ''}
                onChange={handleInputChange}
                className={styles.select}
              >
                <option value="">Seleccionar categoría</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className={styles.formSection}>
            <h3 className={styles.sectionTitle}>Stock y Descuento</h3>
            
            <div className={styles.inputGroup}>
              <label htmlFor="stock" className={styles.label}>Stock Disponible</label>
              <div className={styles.inputWithButton}>
                <input
                  type="number"
                  id="stock"
                  name="stock"
                  value={formData.stock}
                  onChange={handleInputChange}
                  className={styles.input}
                  min="0"
                />
                <button
                  type="button"
                  onClick={handleSaveStock}
                  disabled={!stockChanged || savingStock}
                  className={styles.saveButton}
                >
                  {savingStock ? 'Guardando...' : 'Guardar Stock'}
                </button>
              </div>
            </div>

            <div className={styles.inputGroup}>
              <label htmlFor="discount" className={styles.label}>Descuento (%)</label>
              <div className={styles.inputWithButton}>
                <input
                  type="number"
                  id="discount"
                  name="discount"
                  value={formData.discount}
                  onChange={handleInputChange}
                  className={styles.input}
                  min="0"
                  max="100"
                />
                <button
                  type="button"
                  onClick={handleSaveDiscount}
                  disabled={!discountChanged || savingDiscount}
                  className={styles.saveButton}
                >
                  {savingDiscount ? 'Guardando...' : 'Guardar Descuento'}
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className={styles.formSection}>
          {existingImages.length > 0 && (
            <div className={styles.imageSection}>
              <h4 className={styles.subsectionTitle}>Imágenes Actuales</h4>
              <div className={styles.imageGrid}>
                {existingImages.map((image) => (
                  <div key={image.id} className={styles.imageItem}>
                    <img 
                      src={image.url} 
                      alt="Imagen del producto" 
                      className={styles.imagePreview}
                    />
                    <span className={styles.imageLabel}>Imagen actual</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className={styles.imageSection}>
            <h4 className={styles.subsectionTitle}>Agregar Nuevas Imágenes</h4>
            
            <div className={styles.imageInfo}>
              <p className={styles.imageInfoText}>
                Selecciona imágenes en formato PNG (máximo 1MB cada una)
              </p>
            </div>
            <div className={styles.imageUploadControls}>
              <div className={styles.inputGroup}>
                <input
                  type="file"
                  id="newImages"
                  name="newImages"
                  multiple
                  accept="image/png"
                  onChange={handleNewImageUpload}
                  className={styles.fileInput}
                />
                <label htmlFor="newImages" className={styles.fileInputLabel}>
                  Seleccionar Imágenes
                </label>
              </div>
              
              {newImages.length > 0 && (
                <button
                  type="button"
                  onClick={uploadNewImages}
                  disabled={savingImages}
                  className={styles.saveImagesButton}
                >
                  {savingImages ? 'Guardando Imágenes...' : 'Guardar Imágenes'}
                </button>
              )}
            </div>

            {newImages.length > 0 && (
              <div className={styles.newImagesPreview}>
                <h5 className={styles.previewTitle}>Nuevas Imágenes a Subir:</h5>
                <div className={styles.imageGrid}>
                  {newImages.map((image) => (
                    <div key={image.id} className={styles.imageItem}>
                      <img 
                        src={image.preview} 
                        alt="Nueva imagen" 
                        className={styles.imagePreview}
                      />
                      <button
                        type="button"
                        onClick={() => handleNewImageDelete(image.id)}
                        className={styles.deleteImageButton}
                      >
                        ✕
                      </button>
                      <span className={styles.imageLabel}>Nueva imagen</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className={styles.formActions}>
          <Link href="/stock" className={styles.cancelButton}>
            Cancelar
          </Link>
          <button type="submit" className={styles.submitButton}>
            Actualizar Producto
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditProduct;
