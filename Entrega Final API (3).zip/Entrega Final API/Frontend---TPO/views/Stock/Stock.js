import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Swal from 'sweetalert2';
import Pagination from '../../components/Pagination/Pagination';
import { fetchProducts, deleteProduct, checkProductInOrders } from '../../redux/productsSlice';
import styles from './Stock.module.css';

const Stock = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { items: products, loading, error, currentPage, totalPages } = useSelector(
    (state) => state.products
  );
  const [stockData, setStockData] = useState({});
  const [hasChanges, setHasChanges] = useState(false);
  const [pageSize] = useState(10);

  useEffect(() => {
    dispatch(fetchProducts({ page: currentPage, size: pageSize }));
  }, [dispatch, currentPage, pageSize]);

  useEffect(() => {
    if (products.length > 0) {
      const initialStock = {};
      products.forEach(product => {
        initialStock[product.id] = product.currentStock || product.stock || 0;
      });
      setStockData(initialStock);
    }
  }, [products]);

  const handleStockChange = (productId, newStock) => {
    setStockData(prev => ({
      ...prev,
      [productId]: newStock
    }));
    setHasChanges(true);
  };

  const handleSaveChanges = () => {
    console.log('Guardando cambios de stock:', stockData);
    setHasChanges(false);
    Swal.fire({
      icon: 'success',
      title: 'Éxito',
      text: 'Cambios guardados exitosamente',
      confirmButtonText: 'Aceptar',
      confirmButtonColor: '#6b5d4a'
    });
  };

  const handleRefresh = () => {
    dispatch(fetchProducts({ page: currentPage, size: pageSize }));
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 0 && newPage < totalPages) {
      dispatch(fetchProducts({ page: newPage, size: pageSize }));
    }
  };

  const handleDeleteProduct = async (productId, productName) => {
    try {
      // Verificar si el producto fue comprado
      const checkResult = await dispatch(checkProductInOrders(productId));
      
      if (checkProductInOrders.fulfilled.match(checkResult) && checkResult.payload.inOrders) {
        await Swal.fire({
          icon: 'warning',
          title: 'Advertencia',
          text: 'El producto fue comprado anteriormente y continuará existiendo en dichas órdenes.',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      }

      const result = await Swal.fire({
        icon: 'warning',
        title: '¿Estás seguro?',
        text: `¿Estás seguro de que quieres eliminar el producto "${productName}"?`,
        showCancelButton: true,
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#6b5d4a',
        cancelButtonColor: '#6b5d4a'
      });

      if (!result.isConfirmed) return;

      const deleteResult = await dispatch(deleteProduct(productId));
      
      if (deleteProduct.fulfilled.match(deleteResult)) {
        Swal.fire({
          icon: 'success',
          title: 'Éxito',
          text: 'Producto eliminado exitosamente',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      } else {
        throw new Error(deleteResult.error?.message || 'Error al eliminar');
      }
    } catch (err) {
      console.error('Error al eliminar producto:', err);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: `Error al eliminar producto: ${err.message}`,
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    }
  };

  if (loading) {
    return (
      <div className={styles.stockContainer}>
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Cargando productos...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.stockContainer}>
        <div className={styles.errorContainer}>
          <h3>Error al cargar productos</h3>
          <p>{error}</p>
          <button onClick={handleRefresh} className={styles.retryButton}>
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  const formatPrice = (price) => {
    if (typeof price === 'string') return price;
    return `$${price.toFixed(2)}`;
  };

  const calculateDiscountedPrice = (price, discount) => {
    if (!discount || discount === 0) return null;
    const numericPrice = typeof price === 'string' ? parseFloat(price.replace('$', '')) : price;
    return numericPrice * (1 - discount / 100);
  };

  return (
    <div className={styles.stockContainer}>
      <div className={styles.stockHeader}>
        <button onClick={() => router.push('/')} className={styles.backButton}>
          ← Volver
        </button>
        <h1>Gestión de Stock</h1>
        <div className={styles.stockActions}>
          <Link href="/categories" className={styles.categoriesButton}>
            Categorías
          </Link>
          <Link href="/stock/add-product" className={styles.addProductButton}>
            Agregar Producto
          </Link>
          {hasChanges && (
            <button onClick={handleSaveChanges} className={styles.saveButton}>
              Guardar Cambios
            </button>
          )}
        </div>
      </div>

      <div className={styles.productsGrid}>
        {products.map(product => {
          const hasDiscount = product.discount && product.discount > 0;
          const discountedPrice = hasDiscount ? calculateDiscountedPrice(product.price, product.discount) : null;

          return (
            <div key={product.id} className={styles.productCard}>
              <div className={styles.productImage}>
                <img 
                  src={product.image || '/placeholder-product.jpg'} 
                  alt={product.name}
                  onError={(e) => {
                    e.target.src = '/placeholder-product.jpg';
                  }}
                />
              </div>
              <div className={styles.productInfo}>
                <div className={styles.productMainInfo}>
                  <h3>{product.name}</h3>
                  <div className={styles.priceContainer}>
                    {hasDiscount ? (
                      <>
                        <span className={styles.originalPrice}>{formatPrice(product.price)}</span>
                        <div className={styles.discountedPriceContainer}>
                          <span className={styles.discountedPrice}>
                            {formatPrice(discountedPrice)}
                          </span>
                          <span className={styles.discountPercentage}>
                            -{product.discount}%
                          </span>
                        </div>
                      </>
                    ) : (
                      <span className={styles.regularPrice}>{formatPrice(product.price)}</span>
                    )}
                  </div>
                </div>
                <div className={styles.productActions}>
                  <Link href={`/stock/edit-product/${product.id}`} className={styles.editButton}>
                    Editar
                  </Link>
                  <button 
                    onClick={() => handleDeleteProduct(product.id, product.name)}
                    className={styles.deleteButton}
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {products.length === 0 && !loading && (
        <div className={styles.noResults}>
          <h3>No se encontraron productos</h3>
          <p>No hay productos disponibles para gestionar</p>
          <button onClick={handleRefresh} className={styles.retryButton}>
            Recargar productos
          </button>
        </div>
      )}

      {!loading && !error && totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
          hasNextPage={currentPage < totalPages - 1}
          hasPreviousPage={currentPage > 0}
          loading={loading}
        />
      )}
    </div>
  );
};

export default Stock;
