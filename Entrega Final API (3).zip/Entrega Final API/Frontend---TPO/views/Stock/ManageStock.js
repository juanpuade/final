import StockForm from '../../components/StockForm/StockForm';

const ManageStock = () => {
  return <StockForm />;
};

export default ManageStock;
