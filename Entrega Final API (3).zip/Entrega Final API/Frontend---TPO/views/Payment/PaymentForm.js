import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import styles from './PaymentForm.module.css';
import { createOrder } from '../../redux/ordersSlice';
import { clearCart } from '../../Redux/cartSlice';

const PaymentForm = () => {
  const { cartItems: items, total } = useSelector((state) => state.cart);
  const { user } = useSelector((state) => state.auth);
  const { loading, error } = useSelector((state) => state.orders);
  const dispatch = useDispatch();
  const router = useRouter();
  
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: '',
    email: user?.email || ''
  });
  
  const [formError, setFormError] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    if (!formData.cardNumber || !formData.expiryDate || !formData.cvv || !formData.cardholderName) {
      setFormError('Por favor completa todos los campos');
      return false;
    }
    
    if (formData.cardNumber.length < 16) {
      setFormError('El número de tarjeta debe tener al menos 16 dígitos');
      return false;
    }
    
    if (formData.cvv.length < 3) {
      setFormError('El CVV debe tener al menos 3 dígitos');
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setFormError(null);

    // Preparar los items para la orden
    const orderItems = items.map(item => ({
      productId: item.id,
      quantity: 1
    }));

    const orderData = { items: orderItems };

    const result = await dispatch(createOrder(orderData));
    
    if (createOrder.fulfilled.match(result)) {
      dispatch(clearCart());
      router.push('/orders');
    } else {
      setFormError('Error al procesar el pago. Por favor intenta nuevamente.');
    }
  };

  const getTotalPrice = () => total;

  const displayError = formError || error;

  return (
    <div className={styles.paymentContainer}>
      <div className={styles.paymentContent}>
        <div className={styles.paymentHeader}>
          <h1>Procesar Pago</h1>
          <p>Completa los datos de tu tarjeta para finalizar la compra</p>
        </div>

        <div className={styles.paymentGrid}>
          {/* Resumen del Pedido */}
          <div className={styles.orderSummary}>
            <h3>Resumen del Pedido</h3>
            <div className={styles.summaryItems}>
              {items.map((item) => (
                <div key={item.id} className={styles.summaryItem}>
                  <div className={styles.itemInfo}>
                    <span className={styles.itemName}>{item.name}</span>
                    <span className={styles.itemPrice}>{item.price}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className={styles.summaryTotal}>
              <span>Total: ${getTotalPrice().toFixed(2)}</span>
            </div>
          </div>

          {/* Formulario de Pago */}
          <div className={styles.paymentForm}>
            <form onSubmit={handleSubmit}>
              <div className={styles.formGroup}>
                <label htmlFor="cardNumber">Número de Tarjeta</label>
                <input
                  type="text"
                  id="cardNumber"
                  name="cardNumber"
                  value={formData.cardNumber}
                  onChange={handleInputChange}
                  placeholder="1234 5678 9012 3456"
                  maxLength="19"
                  className={styles.input}
                />
              </div>

              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="expiryDate">Fecha de Vencimiento</label>
                  <input
                    type="text"
                    id="expiryDate"
                    name="expiryDate"
                    value={formData.expiryDate}
                    onChange={handleInputChange}
                    placeholder="MM/AA"
                    maxLength="5"
                    className={styles.input}
                  />
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="cvv">CVV</label>
                  <input
                    type="text"
                    id="cvv"
                    name="cvv"
                    value={formData.cvv}
                    onChange={handleInputChange}
                    placeholder="123"
                    maxLength="4"
                    className={styles.input}
                  />
                </div>
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="cardholderName">Nombre del Titular</label>
                <input
                  type="text"
                  id="cardholderName"
                  name="cardholderName"
                  value={formData.cardholderName}
                  onChange={handleInputChange}
                  placeholder="Juan Pérez"
                  className={styles.input}
                />
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="tu@email.com"
                  className={styles.input}
                />
              </div>

              {displayError && (
                <div className={styles.errorMessage}>
                  {displayError}
                </div>
              )}

              <div className={styles.paymentActions}>
                <button
                  type="button"
                  onClick={() => router.back()}
                  className={styles.cancelButton}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className={styles.payButton}
                >
                  {loading ? 'Procesando...' : 'Realizar Pago'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentForm;
