import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import Swal from 'sweetalert2';
import {
  fetchCategoriesPaginated,
  searchCategoryByName,
  createCategory,
  deleteCategory,
  clearSearchResults,
} from '../../redux/categoriesSlice';
import styles from './Categories.module.css';

const Categories = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const {
    items: categories,
    loading,
    error,
    currentPage,
    totalPages,
    totalElements,
    searchResults,
    searching,
  } = useSelector((state) => state.categories);

  const [pageSize] = useState(10);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [formData, setFormData] = useState({ name: '', description: '' });

  useEffect(() => {
    dispatch(fetchCategoriesPaginated({ page: currentPage, size: pageSize }));
  }, [dispatch, currentPage, pageSize]);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchTerm.trim()) {
        dispatch(searchCategoryByName(searchTerm));
        setShowSearchResults(true);
      } else {
        setShowSearchResults(false);
        dispatch(clearSearchResults());
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [dispatch, searchTerm]);

  const handlePageChange = (newPage) => {
    dispatch(fetchCategoriesPaginated({ page: newPage, size: pageSize }));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      dispatch(searchCategoryByName(searchTerm));
      setShowSearchResults(true);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    const result = await dispatch(createCategory(formData));
    
    if (createCategory.fulfilled.match(result)) {
      setShowCreateForm(false);
      setFormData({ name: '', description: '' });
      Swal.fire({
        icon: 'success',
        title: 'Éxito',
        text: 'Categoría creada exitosamente',
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: `Error al crear categoría: ${result.error?.message}`,
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    }
  };

  const handleDelete = async (id, name) => {
    const confirmResult = await Swal.fire({
      icon: 'warning',
      title: '¿Estás seguro?',
      text: `¿Estás seguro de que quieres eliminar la categoría "${name}"?`,
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#6b5d4a',
      cancelButtonColor: '#6b5d4a'
    });

    if (confirmResult.isConfirmed) {
      const result = await dispatch(deleteCategory(id));
      
      if (deleteCategory.fulfilled.match(result)) {
        Swal.fire({
          icon: 'success',
          title: 'Éxito',
          text: 'Categoría eliminada exitosamente',
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: `Error al eliminar categoría: ${result.error?.message}`,
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
      }
    }
  };

  const closeForms = () => {
    setShowCreateForm(false);
    setFormData({ name: '', description: '' });
  };

  const clearSearch = () => {
    setSearchTerm('');
    setShowSearchResults(false);
    dispatch(clearSearchResults());
  };

  if (loading && categories.length === 0) {
    return (
      <div className={styles.container}>
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Cargando categorías...</p>
        </div>
      </div>
    );
  }

  const displayCategories = showSearchResults ? searchResults : categories;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1>Gestión de Categorías</h1>
        <button className={styles.backButton} onClick={() => router.push('/stock')}>
          ← Volver a Manage
        </button>
      </div>

      <div className={styles.searchSection}>
        <form onSubmit={handleSearch} className={styles.searchForm}>
          <input
            type="text"
            placeholder="Buscar categoría por nombre..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={styles.searchInput}
          />
          <button type="submit" className={styles.searchButton}>
            Buscar
          </button>
          {searchTerm && (
            <button type="button" onClick={clearSearch} className={styles.clearButton}>
              Limpiar
            </button>
          )}
        </form>
      </div>

      <div className={styles.actionsSection}>
        <button className={styles.createButton} onClick={() => setShowCreateForm(true)}>
          + Nueva Categoría
        </button>
      </div>

      <div className={styles.categoriesSection}>
        {error && (
          <div className={styles.errorMessage}>
            <p>Error: {error}</p>
            <button onClick={() => dispatch(fetchCategoriesPaginated({ page: currentPage, size: pageSize }))}>
              Reintentar
            </button>
          </div>
        )}

        {showSearchResults && (
          <div className={styles.searchResults}>
            <h3>Resultados de búsqueda para "{searchTerm}"</h3>
          </div>
        )}

        <div className={styles.categoriesList}>
          {displayCategories.length > 0 ? (
            displayCategories.map((category) => (
              <div key={category.id} className={styles.categoryCard}>
                <div className={styles.categoryInfo}>
                  <h3>{category.name}</h3>
                  <p>{category.description || 'Sin descripción'}</p>
                </div>
                <div className={styles.categoryActions}>
                  <button
                    onClick={() => handleDelete(category.id, category.name)}
                    className={styles.deleteButton}
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p>{showSearchResults ? 'No se encontraron categorías con ese nombre.' : 'No hay categorías.'}</p>
          )}
        </div>

        {!showSearchResults && totalPages > 1 && (
          <div className={styles.pagination}>
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 0 || loading}
              className={styles.paginationButton}
            >
              Anterior
            </button>
            <span className={styles.pageInfo}>
              Página {currentPage + 1} de {totalPages} ({totalElements} categorías)
            </span>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage >= totalPages - 1 || loading}
              className={styles.paginationButton}
            >
              Siguiente
            </button>
          </div>
        )}
      </div>

      {showCreateForm && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <h2>Nueva Categoría</h2>
              <button onClick={closeForms} className={styles.closeButton}>×</button>
            </div>
            <form onSubmit={handleCreate} className={styles.form}>
              <div className={styles.formGroup}>
                <label htmlFor="name">Nombre:</label>
                <input
                  type="text"
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className={styles.input}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="description">Descripción:</label>
                <textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className={styles.textarea}
                  rows="3"
                />
              </div>
              <div className={styles.formActions}>
                <button type="button" onClick={closeForms} className={styles.cancelButton}>
                  Cancelar
                </button>
                <button type="submit" className={styles.submitButton}>
                  Crear Categoría
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

export default Categories;
