import { useState } from 'react';
import Link from 'next/link';
import { useDispatch } from 'react-redux';
import { loginUser } from '../../redux/authSlice';
import { useRouter } from 'next/router';
import styles from './Login.module.css';

const Login = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validación básica
    if (!formData.email || !formData.password) {
      setError('Por favor completa todos los campos');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await dispatch(loginUser({ email: formData.email, password: formData.password }));
      
      if (loginUser.fulfilled.match(result)) {
        // Redirigir al carrito si venía de ahí, sino a home
        const returnUrl = router.query.returnUrl || '/';
        router.push(returnUrl);
      } else {
        setError('Error al iniciar sesión, reintente por favor');
      }
    } catch (err) {
      setError('Error de conexión. Verifica tu conexión a internet.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.loginContainer}>
      <div className={styles.loginForm}>
        <div className={styles.header}>
          <button onClick={() => router.back()} className={styles.backButton}>
            ← Volver
          </button>
          <h1 className={styles.title}>Iniciar Sesión</h1>
        </div>
        
        {error && (
          <div className={styles.errorMessage}>
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.inputGroup}>
            <label htmlFor="email" className={styles.label}>Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="tu@email.com"
              className={styles.input}
            />
          </div>
          
          <div className={styles.inputGroup}>
            <label htmlFor="password" className={styles.label}>Contraseña</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Tu contraseña"
              className={styles.input}
            />
          </div>
          
          <button 
            type="submit" 
            className={styles.loginButton}
            disabled={loading}
          >
            {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
          </button>
          
          <div className={styles.registerLink}>
            <p>¿Aún no tienes usuario?</p>
            <Link href="/register" className={styles.link}>
              Registrarse
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;