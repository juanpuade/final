import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import styles from './Orders.module.css';
import { fetchUserOrders } from '../../redux/ordersSlice';

const Orders = () => {
  const dispatch = useDispatch();
  const { user, isAuthenticated } = useSelector((state) => state.auth);
  const { items: orders, loading, error } = useSelector((state) => state.orders);
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    
    dispatch(fetchUserOrders());
  }, [isAuthenticated, dispatch]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusText = (status) => {
    const statusMap = {
      'PENDING': 'Pendiente',
      'COMPLETED': 'Completada',
      'CANCELLED': 'Cancelada',
      'SHIPPED': 'Enviada'
    };
    return statusMap[status] || status;
  };

  const getStatusClass = (status) => {
    const statusClasses = {
      'PENDING': styles.statusPending,
      'COMPLETED': styles.statusCompleted,
      'CANCELLED': styles.statusCancelled,
      'SHIPPED': styles.statusShipped
    };
    return statusClasses[status] || styles.statusDefault;
  };

  if (!isAuthenticated) {
    return (
      <div className={styles.ordersContainer}>
        <div className={styles.unauthorizedMessage}>
          <h2>Acceso No Autorizado</h2>
          <p>Debes iniciar sesión para ver tus órdenes</p>
          <button 
            onClick={() => router.push('/login')}
            className={styles.loginButton}
          >
            Iniciar Sesión
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className={styles.ordersContainer}>
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Cargando tus órdenes...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.ordersContainer}>
        <div className={styles.errorContainer}>
          <h2>Error al Cargar Órdenes</h2>
          <p>{error}</p>
          <button 
            onClick={() => dispatch(fetchUserOrders())}
            className={styles.retryButton}
          >
            Intentar Nuevamente
          </button>
        </div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className={styles.ordersContainer}>
        <div className={styles.emptyOrders}>
          <div className={styles.emptyIcon}>📦</div>
          <h2>No tienes órdenes</h2>
          <p>Aún no has realizado ninguna compra</p>
          <button 
            onClick={() => router.push('/products')}
            className={styles.shopButton}
          >
            Ir a Productos
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.ordersContainer}>
      <div className={styles.ordersHeader}>
        <h1>Mis Órdenes</h1>
        <p>Gestiona y revisa tus compras anteriores</p>
      </div>

      <div className={styles.ordersList}>
        {orders.map((order, index) => (
          <div key={order.id} className={styles.orderCard}>
            <div className={styles.orderHeader}>
              <div className={styles.orderInfo}>
                <h3>Orden #{index + 1}</h3>
              </div>

            </div>

            <div className={styles.orderItems}>
              <h4>Productos:</h4>
              {order.items?.map((item) => (
                <div key={item.id} className={styles.orderItem}>
                  <div className={styles.itemDetails}>
                    <span className={styles.itemName}>{item.productName}</span>
                    <span className={styles.itemQuantity}>Cantidad: {item.quantity}</span>
                    <span className={styles.itemPrice}>${item.price?.toFixed(2) || '0.00'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Orders;
