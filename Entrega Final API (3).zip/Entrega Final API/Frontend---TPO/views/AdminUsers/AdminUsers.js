import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import Swal from 'sweetalert2';
import { fetchUsers, updateUserRole } from '../../redux/usersSlice';
import styles from './AdminUsers.module.css';

const AdminUsers = () => {
  const router = useRouter();
  const dispatch = useDispatch();

  const { token, user } = useSelector((state) => state.auth);
  const { items: users, loading, error } = useSelector((state) => state.users);

  const [userRoles, setUserRoles] = useState({});
  const [hasChanges, setHasChanges] = useState(false);
  const [saving, setSaving] = useState(false);

  const userRole = user?.role || 'USER';

  // Solo SELLER autenticado puede entrar
  if (!token || userRole !== 'SELLER') {
    return (
      <div className={styles.container}>
        <div className={styles.errorContainer}>
          <h2>Acceso Denegado</h2>
          <p>No tienes permisos para acceder a esta sección.</p>
        </div>
      </div>
    );
  }

  // Cargar usuarios al montar el componente
  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);
 
  // Inicializar roles cuando cambian los usuarios
  useEffect(() => {
    const initialRoles = {};
    users.forEach(user => {
      initialRoles[user.email] = user.role || 'USER';
    });
    setUserRoles(initialRoles);
  }, [users]);

  // Manejar cambio de rol
  const handleRoleChange = (email, newRole) => {
    setUserRoles(prev => ({
      ...prev,
      [email]: newRole
    }));
    setHasChanges(true);
  };

  // Guardar cambios de roles
  const handleSaveChanges = async () => {
    try {
      setSaving(true);
      
      // Obtener usuarios que han cambiado de rol
      const changedUsers = users.filter(user => {
        const originalRole = user.role || 'USER';
        const newRole = userRoles[user.email];
        return originalRole !== newRole;
      });

      // Actualizar cada usuario que cambió de rol usando Redux
      const updatePromises = changedUsers.map((user) => {
        const newRole = userRoles[user.email];
        return dispatch(updateUserRole({
          email: user.email,
          password: user.password || 'contraseña',
          firstName: user.firstName || user.name?.split(' ')[0] || '',
          lastName: user.lastName || user.name?.split(' ').slice(1).join(' ') || '',
          role: newRole
        }));
      });

      await Promise.all(updatePromises);
      
      setHasChanges(false);
      Swal.fire({
        icon: 'success',
        title: 'Éxito',
        text: 'Cambios guardados exitosamente',
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
      
      // Recargar usuarios para obtener datos actualizados
      dispatch(fetchUsers());
    } catch (err) {
      console.error('Error saving changes:', err);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: `Error al guardar cambios: ${err.message}`,
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    } finally {
      setSaving(false);
    }
  };

  // Función para obtener el texto del rol
  const getRoleText = (role) => {
    return role === 'SELLER' ? 'Vendedor' : 'Usuario';
  };

  if (loading) {
    return (
      <div className={styles.container}>
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Cargando usuarios...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.container}>
        <div className={styles.errorContainer}>
          <h3>Error al cargar usuarios</h3>
          <p>{error}</p>
          <button onClick={() => dispatch(fetchUsers())} className={styles.retryButton}>
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <button onClick={() => router.push('/')} className={styles.backButton}>
          ← Volver
        </button>
        <h1>Administración de Usuarios</h1>
        <div className={styles.actions}>
          {hasChanges && (
            <button 
              onClick={handleSaveChanges} 
              className={styles.saveButton}
              disabled={saving}
            >
              {saving ? 'Guardando...' : 'Guardar Cambios'}
            </button>
          )}
        </div>
      </div>

      <div className={styles.usersList}>
        {users.length === 0 ? (
          <div className={styles.noUsers}>
            <h3>No se encontraron usuarios</h3>
            <p>No hay usuarios registrados en el sistema</p>
          </div>
        ) : (
          users.map((user, index) => (
            <div key={user.email || index} className={styles.userCard}>
              <div className={styles.userInfo}>
                <div className={styles.userEmail}>
                  <strong>Email:</strong> {user.email}
                </div>
              </div>
              <div className={styles.userRole}>
                <select
                  id={`role-${user.email}`}
                  value={userRoles[user.email] || user.role || 'USER'}
                  onChange={(e) => handleRoleChange(user.email, e.target.value)}
                  className={styles.roleSelect}
                >
                  <option value="USER">Usuario</option>
                  <option value="SELLER">Vendedor</option>
                </select>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminUsers;
