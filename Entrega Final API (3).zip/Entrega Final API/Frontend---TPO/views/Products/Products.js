import { useState, useMemo, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import HorizontalFilters from '../../components/HorizontalFilters/HorizontalFilters';
import ProductCard from '../../components/ProductCard/ProductCard';
import Pagination from '../../components/Pagination/Pagination';
import { useCart } from '../../context/CartContext';
import { fetchProducts, fetchCategories } from '../../redux/productsSlice';
import styles from './Products.module.css';

const Products = () => {
  const dispatch = useDispatch();
  const { addToCart } = useCart();
  
  // Estado de Redux (datos del servidor)
  const { items: products, loading, error, currentPage, totalPages, categories } = useSelector(
    (state) => state.products
  );

  // Estado local (UI/filtros)
  const [filters, setFilters] = useState({
    category: '',
    rating: '',
    priceFrom: '',
    priceTo: '',
    hasDiscount: false,
    sortOrder: ''
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [pageSize] = useState(10);

  useEffect(() => {
    dispatch(fetchProducts({ page: currentPage, size: pageSize }));
    dispatch(fetchCategories());
  }, [dispatch, currentPage, pageSize]);

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  const handleSearchChange = (term) => {
    setSearchTerm(term);
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 0 && newPage < totalPages) {
      dispatch(fetchProducts({ page: newPage, size: pageSize }));
    }
  };

  const filteredProducts = useMemo(() => {
    if (!Array.isArray(products)) return [];
    
    const filtered = products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = !filters.category || (() => {
        const productCategory = product.category?.name || product.category || product.categoryName;
        return productCategory === filters.category;
      })();
      
      const matchesRating = !filters.rating || (() => {
        const productRating = product.averageRating || product.rating || 0;
        const selectedRating = parseInt(filters.rating);
        return selectedRating === 0 ? !productRating : productRating >= selectedRating;
      })();
      
      const matchesPrice = (() => {
        let productPrice = typeof product.price === 'string' 
          ? parseFloat(product.price.replace('$', '').replace(',', '')) 
          : product.price || 0;
        
        if (product.discount > 0) {
          productPrice = productPrice * (1 - product.discount / 100);
        }
        
        const priceFrom = filters.priceFrom ? parseFloat(filters.priceFrom) : null;
        const priceTo = filters.priceTo ? parseFloat(filters.priceTo) : null;
        
        if (priceFrom !== null && productPrice < priceFrom) return false;
        if (priceTo !== null && productPrice > priceTo) return false;
        return true;
      })();
      
      const matchesDiscount = !filters.hasDiscount || (product.discount > 0);
      
      return matchesSearch && matchesCategory && matchesRating && matchesPrice && matchesDiscount;
    });
    
    if (filters.sortOrder) {
      filtered.sort((a, b) => {
        let priceA = typeof a.price === 'string' ? parseFloat(a.price.replace('$', '')) : a.price || 0;
        let priceB = typeof b.price === 'string' ? parseFloat(b.price.replace('$', '')) : b.price || 0;
        
        if (a.discount > 0) priceA *= (1 - a.discount / 100);
        if (b.discount > 0) priceB *= (1 - b.discount / 100);
        
        return filters.sortOrder === 'priceAsc' ? priceA - priceB : priceB - priceA;
      });
    }
    
    return filtered;
  }, [products, searchTerm, filters]);

  const handleRefresh = () => {
    dispatch(fetchProducts({ page: currentPage, size: pageSize }));
  };

  return (
    <div className={styles.productsContainer}>
      <div className={styles.layoutWrapper}>
        <aside className={styles.filtersSidebar}>
          <HorizontalFilters 
            filters={filters} 
            onFilterChange={handleFilterChange}
            searchTerm={searchTerm}
            onSearchChange={handleSearchChange}
            categories={categories}
          />
        </aside>
        
        <div className={styles.productsSection}>
          {loading && (
            <div className={styles.loadingContainer}>
              <div className={styles.loadingSpinner}></div>
              <p>Cargando productos...</p>
            </div>
          )}

          {error && (
            <div className={styles.errorContainer}>
              <h3>Error al cargar productos</h3>
              <p>{error}</p>
              <button onClick={handleRefresh} className={styles.retryButton}>
                Reintentar
              </button>
            </div>
          )}

          {!loading && !error && (
            <div className={`${styles.productsGrid} ${
              filteredProducts.length === 1 ? styles.singleProduct :
              filteredProducts.length === 2 ? styles.twoProducts :
              filteredProducts.length === 3 ? styles.threeProducts : ''
            }`}>
              {filteredProducts.map(product => (
                <ProductCard 
                  key={product.id} 
                  product={product}
                  className={styles.productCard}
                />
              ))}
            </div>
          )}
          
          {!loading && !error && filteredProducts.length === 0 && (
            <div className={styles.noResults}>
              <h3>No se encontraron productos</h3>
              <p>Intenta ajustar tus filtros o términos de búsqueda</p>
              <button onClick={handleRefresh} className={styles.retryButton}>
                Recargar productos
              </button>
            </div>
          )}

          {!loading && !error && totalPages > 1 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
              hasNextPage={currentPage < totalPages - 1}
              hasPreviousPage={currentPage > 0}
              loading={loading}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default Products;
