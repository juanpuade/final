import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { jwtDecode } from 'jwt-decode';
import Swal from 'sweetalert2';
import { fetchProductById, clearSelectedProduct } from '../../Redux/productsSlice';
import { addToCart } from '../../Redux/cartSlice';
import styles from './ProductDetail.module.css';


const ProductDetail = ({ productId }) => {
  const dispatch = useDispatch();
  const { selectedProduct: product, loading, error } = useSelector((state) => state.products);
  const { token } = useSelector((state) => state.auth);
  const [quantity, setQuantity] = useState(1);

  // Obtener rol del token
  let isVendor = false;
  let isAdmin = false;
  
  if (token) {
    try {
      const decoded = jwtDecode(token);
      const roleRaw = decoded.role || decoded.roles?.[0] || decoded.authorities?.[0] || null;
      let normalizedRole = roleRaw ? String(roleRaw).toUpperCase() : null;
      if (normalizedRole === 'VENDOR' || normalizedRole === 'VENDEDOR') normalizedRole = 'SELLER';
      isVendor = normalizedRole === 'SELLER';
      isAdmin = normalizedRole === 'ADMIN';
    } catch (e) {
      console.warn('Error decoding token:', e);
    }
  }

  useEffect(() => {
    if (productId) {
      dispatch(fetchProductById(productId));
    }
    return () => {
      dispatch(clearSelectedProduct());
    };
  }, [dispatch, productId]);

  const handleQuantityChange = (newQuantity) => {
    if (newQuantity < 1) return;
    if (product && typeof product.stock === 'number') {
      const maxStock = product.stock;
      if (newQuantity > maxStock) {
        setQuantity(maxStock);
        Swal.fire({
          icon: 'warning',
          title: 'Stock insuficiente',
          text: `Solo hay ${maxStock} unidades disponibles`,
          confirmButtonText: 'Aceptar',
          confirmButtonColor: '#6b5d4a'
        });
        return;
      }
    }

    setQuantity(newQuantity);
  };

  const handleAddToCart = () => {
    if (isVendor || isAdmin) {
      Swal.fire({
        icon: 'warning',
        title: 'Acción no permitida',
        text: 'El vendedor no puede agregar productos al carrito',
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
      return;
    }
    if (product) {
      for (let i = 0; i < quantity; i++) {
        dispatch(addToCart(product));
      }
      Swal.fire({
        icon: 'success',
        title: 'Producto agregado',
        text: `Se agregaron ${quantity} ${product.name} al carrito`,
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a'
      });
    }
  };

  const handleRefresh = () => {
    dispatch(fetchProductById(productId));
  };

  if (loading) {
    return (
      <div className={styles.container}>
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Cargando detalles del producto...</p>
        </div>
      </div>
    );
  }

  if (error && !product) {
    return (
      <div className={styles.container}>
        <div className={styles.errorContainer}>
          <h2>Error al cargar el producto</h2>
          <p>{error}</p>
          <button onClick={handleRefresh} className={styles.retryButton}>
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className={styles.container}>
        <div className={styles.notFound}>
          <h2>Producto no encontrado</h2>
          <p>El producto que buscas no existe o ha sido eliminado.</p>
        </div>
      </div>
    );
  }

  const addDisabled = isVendor || isAdmin;

  return (
    <div className={styles.container}>
      <div className={styles.productDetail}>
        <div className={styles.imageSection}>
          <div className={styles.mainImage}>
            <img
              src={product.image || '/placeholder-product.jpg'}
              alt={product.name}
              onError={(e) => {
                e.currentTarget.src = '/placeholder-product.jpg';
              }}
            />
          </div>
          <div className={styles.thumbnailImages}>
            {product.image && product.image !== '/placeholder-product.jpg' ? (
              <div className={styles.thumbnail}>
                <img
                  src={product.image}
                  alt={`${product.name} - Imagen principal`}
                  onError={(e) => {
                    e.currentTarget.src = '/placeholder-product.jpg';
                  }}
                />
              </div>
            ) : (
              <div className={styles.thumbnail}>
                <div className={styles.placeholderThumbnail}></div>
              </div>
            )}
          </div>
        </div>

        <div className={styles.infoSection}>
          <h1 className={styles.productTitle}>{product.name}</h1>

          <div className={styles.priceSection}>
            {product.discount && product.discount > 0 && product.price ? (
              <>
                <span className={styles.originalPrice}>
                  ${typeof product.price === 'string' ? product.price.replace('$', '') : product.price}
                </span>
                <div className={styles.discountedPriceContainer}>
                  <span className={styles.discountedPrice}>
                    {(
                      (typeof product.price === 'string'
                        ? parseFloat(product.price.replace('$', ''))
                        : product.price) *
                      (1 - product.discount / 100)
                    ).toFixed(2)}
                  </span>
                  <span className={styles.discountPercentage}>-{product.discount}%</span>
                </div>
              </>
            ) : (
              <span className={styles.productPrice}>
                $
                {product.price
                  ? typeof product.price === 'string'
                    ? product.price.replace('$', '')
                    : product.price
                  : 'Precio no disponible'}
              </span>
            )}
          </div>

          {product.description && (
            <div className={styles.description}>
              <h3>Descripción</h3>
              <p>{product.description}</p>
            </div>
          )}

          {product.category && (
            <div className={styles.categoryInfo}>
              <h3>Categoría</h3>
              <p>{product.category.name || product.category}</p>
              {product.category.description && (
                <p className={styles.categoryDescription}>{product.category.description}</p>
              )}
            </div>
          )}

          {product.stock !== undefined && product.stock !== null && (
            <div className={styles.stockInfo}>
              <h3>Stock Disponible</h3>
              <p className={styles.stockValue}>{product.stock} unidades</p>
            </div>
          )}

          <div className={styles.addToCartSection}>
            <div className={styles.quantityControls}>
              <label className={styles.quantityLabel}>Cantidad:</label>
              <div className={styles.quantitySelector}>
                <button
                  onClick={() => handleQuantityChange(quantity - 1)}
                  className={styles.quantityButton}
                  disabled={addDisabled}
                >
                  -
                </button>
                <span className={styles.quantity}>{quantity}</span>
                <button
                  onClick={() => handleQuantityChange(quantity + 1)}
                  className={styles.quantityButton}
                  disabled={addDisabled}
                >
                  +
                </button>
              </div>
            </div>

            <button
              onClick={handleAddToCart}
              className={styles.addToCartButton}
              disabled={addDisabled}
            >
              🛒 Agregar al Carrito
            </button>
          </div>

          {addDisabled && (
            <p className={styles.vendorNote}>El vendedor no puede agregar productos al carrito</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
