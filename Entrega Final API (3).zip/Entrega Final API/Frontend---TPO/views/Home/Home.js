"use client";

import { MdDoorSliding, MdTableRestaurant, MdViewComfy, MdViewModule } from "react-icons/md";
import Link from "next/link";
import styles from "./Home.module.css";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchFavorites } from "../../redux/favoritesSlice";

const Home = () => {
  const dispatch = useDispatch();
  const { items: favorites, loading, error } = useSelector(
    (state) => state.favorites
  );

  useEffect(() => {
    dispatch(fetchFavorites());
  }, [dispatch]);

  return (
    <>
      {/* Sección Hero */}
      <section id="home" className={styles.hero}>
        <div className={styles.heroContainer}>
          <div className={styles.heroText}>
            <h1>Diseño que transforma tu espacio</h1>
            <p>
              Descubre muebles funcionales y con estilo, perfectos para crear el
              hogar de tus sueños.
            </p>
            <Link href="/products" className={styles.ctaButton}>
              Explorar Colección
            </Link>
          </div>
          <div className={styles.heroImage}>
            <img src="/images/ImgPrincipal.png" alt="Modern living room" />
          </div>
        </div>
      </section>

      {/* Sección Categorías */}
      <section className={styles.categorias}>
        <div className={styles.categoriaGrid}>
          <Link href="/products" className={styles.categoriaCard}>
            <MdDoorSliding size={50} color="#809671" />
            <h3>Armarios</h3>
            <p>Espaciosos y elegantes para organizar tu vida.</p>
          </Link>

          <Link href="/products" className={styles.categoriaCard}>
            <MdViewModule size={50} color="#809671" />
            <h3>Estanterías</h3>
            <p>Muestra tus tesoros con estilo y versatilidad.</p>
          </Link>

          <Link href="/products" className={styles.categoriaCard}>
            <MdViewComfy size={50} color="#809671" />
            <h3>Cómodas</h3>
            <p>Almacenamiento práctico con un toque de diseño.</p>
          </Link>

          <Link href="/products" className={styles.categoriaCard}>
            <MdTableRestaurant size={50} color="#809671" />
            <h3>Mesas</h3>
            <p>El centro de tus reuniones, robustas y bellas.</p>
          </Link>
        </div>
      </section>

      {/* Sección Favoritos (desde Redux) */}
      <section className={styles.favoritos}>
        <h3 className={styles.tituloFavoritos}>Nuestros Favoritos</h3>
        {loading && <p>Cargando productos...</p>}
        {error && <p>{error}</p>}

        {!loading && !error && favorites.length > 0 && (
          <div className={styles.favoritosWrapper}>
            <div className={styles.favoritosGrid}>
              {favorites.map((item) => (
                <div key={item.id} className={styles.favoritoCard}>
                  <div className={styles.imgContainer}>
                    <img src={item.image} alt={item.name} />
                    <Link
                      href={`/product/${item.id}`}
                      className={styles.overlay}
                    >
                      <button>Ver Detalles</button>
                    </Link>
                  </div>
                  <div className={styles.info}>
                    <h4>{item.name}</h4>
                    <p>{item.description || ""}</p>
                    <p className={styles.precio}>$ {item.price}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </>
  );
};

export default Home;
