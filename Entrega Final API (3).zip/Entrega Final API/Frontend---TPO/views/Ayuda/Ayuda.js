import styles from './Ayuda.module.css';

const Ayuda = () => {
  return (
    <div className={styles.ayuda}>
      <header className={styles.header}>
        <h1>Centro de Ayuda</h1>
        <p>Encontrá información sobre contacto, preguntas frecuentes y devoluciones.</p>
      </header>

      <section className={styles.section}>
        <div className={styles.card}>
          <h2>Información de Contacto</h2>
          <p>Si necesitás asistencia, podés comunicarte con nosotros:</p>
          <ul>
            <li><strong>Email:</strong> soporte@habirate.com</li>
            <li><strong>Teléfono:</strong> +54 11 5555-5555</li>
            <li><strong>Horario:</strong> Lunes a Viernes de 9 a 18 hs</li>
          </ul>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.card}>
          <h2>Preguntas Frecuentes</h2>
          <details>
            <summary>¿Cuánto tarda en llegar mi pedido?</summary>
            <p>Los envíos suelen demorar entre 3 y 7 días hábiles, dependiendo de tu ubicación.</p>
          </details>
          <details>
            <summary>¿Puedo modificar mi pedido luego de realizarlo?</summary>
            <p>Sí, podés contactarnos dentro de las primeras 24 horas luego de hacer la compra para realizar modificaciones.</p>
          </details>
          <details>
            <summary>¿Ofrecen envíos internacionales?</summary>
            <p>Actualmente solo realizamos envíos dentro de Argentina.</p>
          </details>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.card}>
          <h2>Envíos y Devoluciones</h2>
          <p>Trabajamos con empresas de envío confiables para que tus productos lleguen en tiempo y forma.</p>
          <ul>
            <li><strong>Envíos:</strong> Gratuitos en compras mayores a $50.000.</li>
            <li><strong>Devoluciones:</strong> Dentro de los 10 días posteriores a la entrega, en su empaque original.</li>
            <li><strong>Reembolsos:</strong> Se procesan dentro de los 5 días hábiles luego de recibir el producto devuelto.</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default Ayuda;
