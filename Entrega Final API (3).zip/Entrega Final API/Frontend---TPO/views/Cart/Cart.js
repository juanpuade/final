import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import Swal from 'sweetalert2';
import styles from './Cart.module.css';
import { removeFromCart, clearCart, increaseQuantity, decreaseQuantity } from '../../Redux/cartSlice';

const Cart = () => {
  const dispatch = useDispatch();
  const { cartItems: items, total } = useSelector((state) => state.cart);
  const { isAuthenticated, user } = useSelector((state) => state.auth);
  const router = useRouter();

  // Bloquear acceso a admin o seller
  if (user && (user.role === 'ADMIN' || user.role === 'SELLER')) {
    return (
      <div className={styles.cartContainer}>
        <div className={styles.emptyCart}>
          <h2>No tienes acceso al carrito</h2>
          <p>Los usuarios administradores y vendedores no pueden usar el carrito.</p>
          <button onClick={() => router.push('/')} className={styles.shopButton}>
            Volver al inicio
          </button>
        </div>
      </div>
    );
  }

  const handleCheckout = () => {
    if (!isAuthenticated) {
      router.push(`/login?returnUrl=${encodeURIComponent('/cart')}`);
      return;
    }
    router.push('/payment');
  };

  const handleRemoveFromCart = async (itemId, itemName) => {
    const result = await Swal.fire({
      icon: 'warning',
      title: '¿Estás seguro?',
      text: `¿Deseas eliminar "${itemName}" del carrito?`,
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#6b5d4a',
      cancelButtonColor: '#6b5d4a'
    });

    if (result.isConfirmed) {
      dispatch(removeFromCart(itemId));
      Swal.fire({
        icon: 'success',
        title: 'Producto eliminado',
        text: 'El producto ha sido eliminado del carrito',
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a',
        timer: 2000,
        showConfirmButton: false
      });
    }
  };

  const handleClearCart = async () => {
    const result = await Swal.fire({
      icon: 'warning',
      title: '¿Estás seguro?',
      text: `¿Deseas eliminar todos los productos del carrito?`,
      showCancelButton: true,
      confirmButtonText: 'Sí, limpiar carrito',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#6b5d4a',
      cancelButtonColor: '#6b5d4a'
    });

    if (result.isConfirmed) {
      dispatch(clearCart());
      Swal.fire({
        icon: 'success',
        title: 'Carrito limpiado',
        text: 'Todos los productos han sido eliminados del carrito',
        confirmButtonText: 'Aceptar',
        confirmButtonColor: '#6b5d4a',
        timer: 2000,
        showConfirmButton: false
      });
    }
  };

  if (items.length === 0) {
    return (
      <div className={styles.cartContainer}>
        <div className={styles.emptyCart}>
          <div className={styles.emptyIcon}>Carrito</div>
          <h2>Tu carrito está vacío</h2>
          <p>Agrega algunos productos para comenzar tu compra</p>
          <button
            onClick={() => router.push('/products')}
            className={styles.shopButton}
          >
            Ir a Productos
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.cartContainer}>
      <div className={styles.cartContent}>
        <div className={styles.cartItems}>
          {items.map((item) => (
            <div key={item.id} className={styles.cartItem}>
              <div className={styles.itemInfo}>
                <h3 className={styles.itemName}>{item.name}</h3>
                <p className={styles.itemPrice}>${typeof item.price === 'string' ? item.price.replace('$', '') : item.price}</p>
              </div>

              <div className={styles.quantityControls}>
                <button
                  className={styles.quantityButton}
                  onClick={() => dispatch(decreaseQuantity(item.id))}
                >
                  -
                </button>
                <span className={styles.quantity}>{item.quantity}</span>
                <button
                  className={styles.quantityButton}
                  onClick={() => dispatch(increaseQuantity(item.id))}
                >
                  +
                </button>
              </div>

              <div className={styles.itemTotal}>
                $
                {(
                  parseFloat(
                    typeof item.price === 'string'
                      ? item.price.replace('$', '')
                      : item.price
                  ) * item.quantity
                ).toFixed(2)}
              </div>

              <button
                onClick={() => handleRemoveFromCart(item.id, item.name)}
                className={styles.removeButton}
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        <div className={styles.cartSummary}>
          <div className={styles.summaryContent}>
            <h3>Resumen de Compra</h3>
            <div className={styles.summaryRow}>
              <span>Productos ({items.reduce((acc, item) => acc + item.quantity, 0)})</span>
              <span>${total.toFixed(2)}</span>
            </div>
            <div className={styles.summaryRow}>
              <span>Envío</span>
              <span>Gratis</span>
            </div>
            <div className={styles.summaryTotal}>
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>

            <div className={styles.cartActions}>
              <button onClick={handleClearCart} className={styles.clearButton}>
                Limpiar Carrito
              </button>
              <button onClick={handleCheckout} className={styles.checkoutButton}>
                Proceder al Pago
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
