import { createContext, useContext } from "react";

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const value = {
    items: [],
    addToCart: () => {},
    removeFromCart: () => {},
    clearCart: () => {},
    getTotalPrice: () => 0,
    getTotalItems: () => 0,
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
