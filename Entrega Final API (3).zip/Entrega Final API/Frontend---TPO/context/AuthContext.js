import { createContext, useContext, useReducer, useEffect } from 'react';

const AuthContext = createContext();

// Acá manejamos todos los cambios de estado de la autenticación
// Este reducer recibe el estado actual y una acción, y según el tipo de acción
// actualiza el estado de autenticación del usuario (implementación original deprecada)
const authReducer = (state, action) => {
  switch (action.type) {
    case 'LOGIN':
      return {
        ...state,
        isAuthenticated: true,
        user: action.payload.user,
        token: action.payload.token
      };
    case 'LOGOUT':
      return {
        ...state,
        isAuthenticated: false,
        user: null,
        token: null
      };
    case 'REGISTER':
      return {
        ...state,
        isAuthenticated: true,
        user: action.payload.user,
        token: action.payload.token
      };
    case 'INIT_AUTH':
      return {
        ...state,
        isAuthenticated: action.payload.isAuthenticated,
        user: action.payload.user,
        token: action.payload.token
      };
    default:
      return state;
  }
};

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, {
    isAuthenticated: false,
    user: null,
    token: null
  });

  // Cuando arranca la app, chequeamos si el usuario ya estaba logueado
  useEffect(() => {
    const checkAuthStatus = () => {
      try {
        // Buscamos el token y los datos del usuario en el localStorage
        const token = localStorage.getItem('jwtToken');
        const userData = localStorage.getItem('userData');
        
        if (token && userData && userData !== 'undefined' && userData !== 'null') {
          try {
            const user = JSON.parse(userData);
            dispatch({ 
              type: 'INIT_AUTH', 
              payload: { 
                isAuthenticated: true, 
                user, 
                token 
              } 
            });
          } catch (error) {
            console.error('Error parsing user data:', error);
            localStorage.removeItem('jwtToken');
            localStorage.removeItem('userData');
            dispatch({ type: 'LOGOUT' });
          }
        } else {
          // Si no hay datos válidos, el usuario no está logueado
          dispatch({ type: 'LOGOUT' });
        }
      } catch (error) {
        console.error('Error checking auth status:', error);
        localStorage.removeItem('jwtToken');
        localStorage.removeItem('userData');
        dispatch({ type: 'LOGOUT' });
      }
    };

    checkAuthStatus();
  }, []);

  const login = async (email, password) => {
    try {
      const response = await fetch('http://localhost:4002/auth/authenticate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password }),
        mode: 'cors',
      });

      if (!response.ok) {
        return { 
          success: false, 
          error: 'Ocurrió un error al iniciar sesión, por favor reintente' 
        };
      }

      const data = await response.json();
      const user = data.user || data.userData || data;
      const token = data.accessToken || data.access_token;

      if (!user) {
        throw new Error('Respuesta del servidor inválida: faltan datos de usuario');
      }

      if (!token) {
        throw new Error('Respuesta del servidor inválida: falta token de autenticación');
      }

      // Guardamos el token y los datos del usuario en el localStorage
      localStorage.setItem('jwtToken', token);
      localStorage.setItem('userData', JSON.stringify(user));

      dispatch({ type: 'LOGIN', payload: { user, token } });

      return { success: true, user, token };
    } catch (error) {
      console.error('Login error:', error);
      return { 
        success: false, 
        error: 'Ocurrió un error al iniciar sesión, por favor reintente' 
      };
    }
  };

  const logout = () => {
    // Limpiamos el localStorage y deslogueamos al usuario
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('userData');
    dispatch({ type: 'LOGOUT' });
  };

  const register = async (userData) => {
    try {
      const response = await fetch('http://localhost:4002/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData),
        mode: 'cors',
      });

      if (!response.ok) {
        return { 
          success: false, 
          error: 'Ocurrió un error al crear la cuenta, por favor reintente' 
        };
      }

      const data = await response.json();
      const user = data.user || data.userData || data;
      const token = data.access_token || data.accessToken;

      if (!user) {
        throw new Error('Respuesta del servidor inválida: faltan datos de usuario');
      }

      if (!token) {
        throw new Error('Respuesta del servidor inválida: falta token de autenticación');
      }

      // Guardamos el token y los datos del usuario en el localStorage
      localStorage.setItem('jwtToken', token);
      localStorage.setItem('userData', JSON.stringify(user));
      dispatch({ type: 'REGISTER', payload: { user, token } });

      return { success: true, user, token };
    } catch (error) {
      console.error('Register error:', error);
      return { 
        success: false, 
        error: 'Ocurrió un error al crear la cuenta, por favor reintente' 
      };
    }
  };

  const value = {
    ...state,
    login,
    logout,
    register
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
