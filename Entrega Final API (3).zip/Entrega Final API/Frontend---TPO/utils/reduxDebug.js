/**
 * Utilidades para debugging de Redux
 * 
 * Uso en la consola del navegador:
 * 
 * // Ver el estado actual
 * window.__REDUX_DEBUG__.getState()
 * 
 * // Ver solo el estado de auth
 * window.__REDUX_DEBUG__.getAuthState()
 * 
 * // Despachar una acción de logout (para testing)
 * window.__REDUX_DEBUG__.dispatchLogout()
 */
export const setupReduxDebug = (store) => {
  if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
    window.__REDUX_DEBUG__ = {
      getState: () => {
        console.log('Estado completo de Redux:', store.getState());
        return store.getState();
      },
      getAuthState: () => {
        const authState = store.getState().auth;
        console.log('Estado de Auth:', authState);
        return authState;
      },
      dispatchLogout: () => {
        const { logout } = require('../redux/authSlice');
        store.dispatch(logout());
        console.log('Logout despachado');
      },
    };
  }
};

