import Layout from '../../../components/Layout/Layout';
import EditProduct from '../../../views/Stock/EditProduct';

const EditProductPage = ({ productId }) => {
  return (
    <Layout>
      <EditProduct productId={productId} />
    </Layout>
  );
};

export async function getServerSideProps({ params }) {
  return {
    props: {
      productId: params.id
    }
  };
}

export default EditProductPage;
