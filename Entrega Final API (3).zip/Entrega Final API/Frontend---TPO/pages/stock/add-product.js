import Layout from '../../components/Layout/Layout';
import AddProduct from '../../views/Stock/AddProduct';

const AddProductPage = () => {
  return (
    <Layout>
      <AddProduct />
    </Layout>
  );
};

export default AddProductPage;
