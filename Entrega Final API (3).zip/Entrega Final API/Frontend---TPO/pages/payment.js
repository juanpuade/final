import Layout from '../components/Layout/Layout';
import PaymentForm from '../views/Payment/PaymentForm';

const PaymentPage = () => {
  return (
    <Layout>
      <PaymentForm />
    </Layout>
  );
};

export default PaymentPage;

