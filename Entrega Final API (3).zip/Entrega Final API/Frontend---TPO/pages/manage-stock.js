import Layout from '../components/Layout/Layout';
import ManageStock from '../views/Stock/ManageStock';

const ManageStockPage = () => {
  return (
    <Layout>
      <ManageStock />
    </Layout>
  );
};

export default ManageStockPage;
