import Layout from '../components/Layout/Layout';
import Cart from '../views/Cart/Cart';

const CartPage = () => {
  return (
    <Layout>
      <Cart />
    </Layout>
  );
};

export default CartPage;
