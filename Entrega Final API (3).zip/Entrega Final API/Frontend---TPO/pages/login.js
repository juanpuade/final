import Layout from '../components/Layout/Layout';
import Login from '../views/Login/Login';

const LoginPage = () => {
  return (
    <Layout>
      <Login />
    </Layout>
  );
};

export default LoginPage;