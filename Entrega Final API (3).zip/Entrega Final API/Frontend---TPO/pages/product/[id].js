// pages/product/[id].js
import Layout from '../../components/Layout/Layout';
import ProductDetail from '../../views/Products/ProductDetail';

const ProductPage = ({ productId }) => {
  return (
    <Layout>
      <ProductDetail productId={productId} />
    </Layout>
  );
};

export async function getServerSideProps({ params }) {
  return {
    props: {
      productId: params.id,
    },
  };
}

export default ProductPage;
