import Layout from '../components/Layout/Layout';
import Stock from '../views/Stock/Stock';

const StockPage = () => {
  return (
    <Layout>
      <Stock />
    </Layout>
  );
};

export default StockPage;
