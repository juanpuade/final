import '../styles/globals.css';
import { useEffect } from 'react';
import { CartProvider } from "../context/CartContext";
import { Provider } from 'react-redux';
import { store } from '../redux/store';
import AuthInitializer from '../components/AuthInitializer';
import { setupReduxDebug } from '../utils/reduxDebug';

const MyApp = ({ Component, pageProps }) => {
  useEffect(() => {
    setupReduxDebug(store);
  }, []);

  return (
    <Provider store={store}>
      <AuthInitializer>
        <CartProvider>
          <Component {...pageProps} />
        </CartProvider>
      </AuthInitializer>
    </Provider>
  );
};

export default MyApp;

