import Layout from '../components/Layout/Layout';
import Register from '../views/Register/Register';

const RegisterPage = () => {
  return (
    <Layout>
      <Register />
    </Layout>
  );
};

export default RegisterPage;
