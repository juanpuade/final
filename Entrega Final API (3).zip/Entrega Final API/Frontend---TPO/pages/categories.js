import Categories from '../views/Categories/Categories';
import Layout from '../components/Layout/Layout';

const CategoriesPage = () => {
  return (
    <Layout>
      <Categories />
    </Layout>
  );
};

export default CategoriesPage;
