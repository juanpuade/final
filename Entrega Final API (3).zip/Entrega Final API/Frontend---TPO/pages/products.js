import Layout from '../components/Layout/Layout';
import Products from '../views/Products/Products';

const ProductsPage = () => {
  return (
    <Layout>
      <Products />
    </Layout>
  );
};

export default ProductsPage;
