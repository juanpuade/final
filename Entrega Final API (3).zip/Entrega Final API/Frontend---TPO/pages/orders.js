import Layout from '../components/Layout/Layout';
import Orders from '../views/Orders/Orders';

const OrdersPage = () => {
  return (
    <Layout>
      <Orders />
    </Layout>
  );
};

export default OrdersPage;

