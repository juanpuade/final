import Layout from '../components/Layout/Layout';
import Ayuda from '../views/Ayuda/Ayuda';

const AyudaPage = () => {
  return (
    <Layout>
      <Ayuda />
    </Layout>
  );
};

export default AyudaPage;