import Layout from '../components/Layout/Layout';
import AdminUsers from '../views/AdminUsers/AdminUsers';

const AdminUsersPage = () => {
  return (
    <Layout>
      <AdminUsers />
    </Layout>
  );
};

export default AdminUsersPage;
