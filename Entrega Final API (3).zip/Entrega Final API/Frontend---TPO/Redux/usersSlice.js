import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = "http://localhost:4002/users";

export const fetchUsers = createAsyncThunk("users/fetchUsers", async (_, { getState }) => {
  const { token } = getState().auth;
  const { data } = await axios.get(API_URL, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return data;
});

export const updateUserRole = createAsyncThunk("users/updateUserRole", async (userData, { getState }) => {
  const { token } = getState().auth;
  const { data } = await axios.put(API_URL, userData, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return data;
});

const usersSlice = createSlice({
  name: "users",
  initialState: {
    items: [],
    loading: false,
    error: null,
  },
  reducers: {
    clearUsers: (state) => {
      state.items = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.items = Array.isArray(action.payload) ? action.payload : [];
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(updateUserRole.fulfilled, (state, action) => {
        const index = state.items.findIndex((user) => user.email === action.payload.email);
        if (index !== -1) {
          state.items[index] = action.payload;
        }
      });
  },
});

export default usersSlice.reducer;
export const { clearUsers } = usersSlice.actions;

