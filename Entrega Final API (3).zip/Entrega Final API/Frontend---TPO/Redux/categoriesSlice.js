import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = "http://localhost:4002";

// Thunks
export const fetchCategoriesPaginated = createAsyncThunk(
  "categories/fetchCategoriesPaginated",
  async ({ page = 0, size = 10 }, { getState }) => {
    const { token } = getState().auth;
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    const { data } = await axios.get(`${API_URL}/categories?page=${page}&size=${size}`, { headers });
    return {
      items: data.content || data,
      currentPage: page,
      totalPages: data.totalPages || 1,
      totalElements: data.totalElements || (data.content || data).length,
    };
  }
);

export const searchCategoryByName = createAsyncThunk(
  "categories/searchCategoryByName",
  async (name, { getState }) => {
    const { token } = getState().auth;
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    const { data } = await axios.get(`${API_URL}/categories/name/${encodeURIComponent(name)}`, { headers });
    return Array.isArray(data) ? data : [data];
  }
);

export const createCategory = createAsyncThunk(
  "categories/createCategory",
  async (categoryData, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.post(`${API_URL}/categories`, categoryData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return data;
  }
);

export const deleteCategory = createAsyncThunk(
  "categories/deleteCategory",
  async (id, { getState }) => {
    const { token } = getState().auth;
    await axios.delete(`${API_URL}/categories/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return id;
  }
);

const categoriesSlice = createSlice({
  name: "categories",
  initialState: {
    items: [],
    loading: false,
    error: null,
    currentPage: 0,
    totalPages: 0,
    totalElements: 0,
    searchResults: [],
    searching: false,
  },
  reducers: {
    clearCategories: (state) => {
      state.items = [];
    },
    clearSearchResults: (state) => {
      state.searchResults = [];
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Categories Paginated
      .addCase(fetchCategoriesPaginated.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCategoriesPaginated.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload.items;
        state.currentPage = action.payload.currentPage;
        state.totalPages = action.payload.totalPages;
        state.totalElements = action.payload.totalElements;
      })
      .addCase(fetchCategoriesPaginated.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Search Category
      .addCase(searchCategoryByName.pending, (state) => {
        state.searching = true;
      })
      .addCase(searchCategoryByName.fulfilled, (state, action) => {
        state.searching = false;
        state.searchResults = action.payload;
      })
      .addCase(searchCategoryByName.rejected, (state) => {
        state.searching = false;
        state.searchResults = [];
      })
      // Create Category
      .addCase(createCategory.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
      })
      // Delete Category
      .addCase(deleteCategory.fulfilled, (state, action) => {
        state.items = state.items.filter((c) => c.id !== action.payload);
      });
  },
});

export default categoriesSlice.reducer;
export const { clearCategories, clearSearchResults } = categoriesSlice.actions;

