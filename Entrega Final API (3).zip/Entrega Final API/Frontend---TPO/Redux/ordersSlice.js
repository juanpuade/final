import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = "http://localhost:4002";

// Thunks
export const fetchUserOrders = createAsyncThunk(
  "orders/fetchUserOrders",
  async (_, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.get(`${API_URL}/orders/user/all`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const ordersData = data.content || data;
    return Array.isArray(ordersData) ? ordersData : [];
  }
);

export const createOrder = createAsyncThunk(
  "orders/createOrder",
  async (orderData, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.post(`${API_URL}/orders`, orderData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return data;
  }
);

export const processPayment = createAsyncThunk(
  "orders/processPayment",
  async (_, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.put(`${API_URL}/pay`, {}, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return data;
  }
);

const ordersSlice = createSlice({
  name: "orders",
  initialState: {
    items: [],
    loading: false,
    error: null,
    currentOrder: null,
    paymentProcessing: false,
  },
  reducers: {
    clearOrders: (state) => {
      state.items = [];
    },
    clearCurrentOrder: (state) => {
      state.currentOrder = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch User Orders
      .addCase(fetchUserOrders.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserOrders.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchUserOrders.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Create Order
      .addCase(createOrder.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createOrder.fulfilled, (state, action) => {
        state.loading = false;
        state.currentOrder = action.payload;
        state.items.unshift(action.payload);
      })
      .addCase(createOrder.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Process Payment
      .addCase(processPayment.pending, (state) => {
        state.paymentProcessing = true;
      })
      .addCase(processPayment.fulfilled, (state) => {
        state.paymentProcessing = false;
      })
      .addCase(processPayment.rejected, (state, action) => {
        state.paymentProcessing = false;
        state.error = action.error.message;
      });
  },
});

export default ordersSlice.reducer;
export const { clearOrders, clearCurrentOrder } = ordersSlice.actions;

