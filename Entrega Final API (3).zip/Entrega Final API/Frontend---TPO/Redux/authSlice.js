import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = "http://localhost:4002/auth";

// Helper para decodificar el JWT sin librerías extras
const decodeToken = (token) => {
  if (!token) return {};
  try {
    const [, payloadBase64] = token.split(".");
    const json = atob(payloadBase64.replace(/-/g, "+").replace(/_/g, "/"));
    const payload = JSON.parse(json);
    return {
      email: payload.email || payload.sub || null,
      role: payload.role || null,
    };
  } catch {
    return {};
  }
};

// LOGIN
export const loginUser = createAsyncThunk(
  "auth/loginUser",
  async ({ email, password }, { rejectWithValue }) => {
    try {
      const { data } = await axios.post(`${API_URL}/authenticate`, {
        email,
        password,
      });

      // token puede venir como access_token o accessToken
      const token = data.accessToken || data.access_token || data.token;

      // Intentamos tomar email/role de la respuesta directa
      let userEmail = data.email || email || null;
      let userRole = data.role || null;

      // Si no vinieron en el JSON, los buscamos dentro del JWT
      if (!userEmail || !userRole) {
        const decoded = decodeToken(token);
        if (!userEmail) userEmail = decoded.email || userEmail;
        if (!userRole) userRole = decoded.role || "USER";
      }

      const user = {
        email: userEmail,
        role: userRole || "USER",
      };

      return { user, token };
    } catch (error) {
      const message =
        error.response?.data?.message ||
        error.response?.data?.error ||
        "Error al iniciar sesión";
      return rejectWithValue(message);
    }
  }
);

// REGISTER
export const registerUser = createAsyncThunk(
  "auth/registerUser",
  async (
    { firstname, lastname, email, password, role = "USER" },
    { rejectWithValue }
  ) => {
    try {
      const { data } = await axios.post(`${API_URL}/register`, {
        firstname,
        lastname,
        email,
        password,
        role,
      });

      const token = data.accessToken || data.access_token || data.token;

      let userEmail = data.email || email || null;
      let userRole = data.role || role || null;

      if (!userEmail || !userRole) {
        const decoded = decodeToken(token);
        if (!userEmail) userEmail = decoded.email || userEmail;
        if (!userRole) userRole = decoded.role || "USER";
      }

      const user = {
        email: userEmail,
        role: userRole || "USER",
      };

      return { user, token };
    } catch (error) {
      const message =
        error.response?.data?.message ||
        error.response?.data?.error ||
        "Error al registrarse";
      return rejectWithValue(message);
    }
  }
);

// INIT AUTH: sin localStorage → siempre arranca deslogueado
export const initAuth = createAsyncThunk("auth/initAuth", async () => {
  return { isAuthenticated: false, user: null, token: null };
});

const authSlice = createSlice({
  name: "auth",
  initialState: {
    isAuthenticated: false,
    user: null,   // { email, role }
    token: null,  // JWT
    loading: false,
    error: null,
  },
  reducers: {
    logout: (state) => {
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      state.error = null;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Login
      .addCase(loginUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loading = false;
        state.isAuthenticated = true;
        state.user = action.payload.user;   // { email, role }
        state.token = action.payload.token; // jwt
        state.error = null;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.loading = false;
        state.isAuthenticated = false;
        state.error = action.payload || action.error.message;
      })
      // Register
      .addCase(registerUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.loading = false;
        state.isAuthenticated = true;
        state.user = action.payload.user;
        state.token = action.payload.token;
        state.error = null;
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.loading = false;
        state.isAuthenticated = false;
        state.error = action.payload || action.error.message;
      })
      // Init Auth
      .addCase(initAuth.pending, (state) => {
        state.loading = true;
      })
      .addCase(initAuth.fulfilled, (state, action) => {
        state.loading = false;
        state.isAuthenticated = action.payload.isAuthenticated;
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(initAuth.rejected, (state) => {
        state.loading = false;
        state.isAuthenticated = false;
        state.user = null;
        state.token = null;
      });
  },
});

export default authSlice.reducer;
export const { logout, clearError } = authSlice.actions;
