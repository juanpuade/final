import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = "http://localhost:4002";
const FAVORITE_IDS = [1, 2, 3, 5];

const fetchProductImage = async (productId) => {
  const { data } = await axios.get(`${API_URL}/images?id=0&productId=${productId}`);

  if (data.file && typeof data.file === "string") {
    return `data:image/jpeg;base64,${data.file}`;
  }

  return data.url || data.imageUrl || data.src || null;
};

// devuelve null si falla
const safeFetchProductImage = (productId) =>
  fetchProductImage(productId).catch((e) => {
    console.warn(`Error fetching image for product ${productId}:`, e);
    return null;
  });

export const fetchFavorites = createAsyncThunk("favorites/fetchFavorites", async () => {
  const products = await Promise.all(
    FAVORITE_IDS.map(async (id) => {
      // Si falla este axios, el tjhunk se rechaza y cae en .rejected (extraReducers)
      const { data: product } = await axios.get(`${API_URL}/products/${id}`);

      const image = await safeFetchProductImage(id);

      return {
        ...product,
        image: image || product.image || "/placeholder-product.jpg",
      };
    })
  );

  // no filtra null porwque `safeFetchProductImage` nunca retorna null
  // solo null de imagenm, y siempre devolvemos un producto válido.
  return products;
});

const favoritesSlice = createSlice({
  name: "favorites",
  initialState: {
    items: [],
    loading: false,
    error: null,
  },
  reducers: {
    clearFavorites: (state) => {
      state.items = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchFavorites.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchFavorites.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchFavorites.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error?.message || "Error al cargar favoritos";
      });
  },
});

export default favoritesSlice.reducer;
export const { clearFavorites } = favoritesSlice.actions;
