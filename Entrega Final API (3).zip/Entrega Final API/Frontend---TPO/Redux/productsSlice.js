import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = "http://localhost:4002";

const fetchProductImage = async (productId) => {
  const { data } = await axios.get(`${API_URL}/images?id=0&productId=${productId}`);

  if (data.file && typeof data.file === "string") {
    return `data:image/jpeg;base64,${data.file}`;
  }

  return data.url || data.imageUrl || data.src || null;
};

const safeFetchProductImage = (productId) =>
  fetchProductImage(productId).catch(() => null);

// Thunks
export const fetchProducts = createAsyncThunk(
  "products/fetchProducts",
  async ({ page = 0, size = 10 }) => {
    const { data } = await axios.get(`${API_URL}/products/all?page=${page}&size=${size}`);
    const productsData = data.content || data.products || (Array.isArray(data) ? data : []);

    const productsWithImages = await Promise.all(
      productsData.map(async (product) => {
        const imageUrl = await safeFetchProductImage(product.id);

        return {
          ...product,
          image: imageUrl || product.image || "/placeholder-product.jpg",
        };
      })
    );

    return {
      items: productsWithImages,
      currentPage: page,
      totalPages: data.totalPages || 1,
      totalElements: data.totalElements || productsData.length,
    };
  }
);

export const fetchProductById = createAsyncThunk(
  "products/fetchProductById",
  async (productId) => {
    const { data: product } = await axios.get(`${API_URL}/products/${productId}`);
    const imageUrl = await safeFetchProductImage(productId);

    return {
      ...product,
      image: imageUrl || product.image || "/placeholder-product.jpg",
    };
  }
);

export const fetchCategories = createAsyncThunk(
  "products/fetchCategories",
  async (_, { getState }) => {
    const { token } = getState().auth;
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    const { data } = await axios.get(`${API_URL}/categories?page=0&size=100`, { headers });
    const categoriesData = data.content || data;
    return Array.isArray(categoriesData) ? categoriesData : [];
  }
);

export const createProduct = createAsyncThunk(
  "products/createProduct",
  async (productData, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.post(`${API_URL}/products`, productData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return data;
  }
);

export const deleteProduct = createAsyncThunk(
  "products/deleteProduct",
  async (productId, { getState }) => {
    const { token } = getState().auth;
    await axios.delete(`${API_URL}/products/${productId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return productId;
  }
);

export const updateStock = createAsyncThunk(
  "products/updateStock",
  async ({ productId, stock }, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.put(
      `${API_URL}/products/${productId}/stock/${stock}`,
      {},
      { headers: { Authorization: `Bearer ${token}` } }
    );
    return { productId, stock, data };
  }
);

export const updateDiscount = createAsyncThunk(
  "products/updateDiscount",
  async ({ productId, discount }, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.put(
      `${API_URL}/products/${productId}/discount/${discount}`,
      {},
      { headers: { Authorization: `Bearer ${token}` } }
    );
    return { productId, discount, data };
  }
);

export const uploadProductImage = createAsyncThunk(
  "products/uploadProductImage",
  async ({ file, productId }, { getState }) => {
    const { token } = getState().auth;
    const formData = new FormData();
    formData.append("file", file);
    formData.append("name", "imagen");
    formData.append("productId", productId.toString());

    const { data } = await axios.post(`${API_URL}/images`, formData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return data;
  }
);

export const checkProductInOrders = createAsyncThunk(
  "products/checkProductInOrders",
  async (productId, { getState }) => {
    const { token } = getState().auth;
    const { data } = await axios.get(`${API_URL}/orders/product/${productId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return { productId, inOrders: data === true || data === "true" };
  }
);

const productsSlice = createSlice({
  name: "products",
  initialState: {
    items: [],
    loading: false,
    error: null,
    currentPage: 0,
    totalPages: 0,
    totalElements: 0,
    categories: [],
    selectedProduct: null,
  },
  reducers: {
    clearProducts: (state) => {
      state.items = [];
    },
    clearSelectedProduct: (state) => {
      state.selectedProduct = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Products
      .addCase(fetchProducts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload.items;
        state.currentPage = action.payload.currentPage;
        state.totalPages = action.payload.totalPages;
        state.totalElements = action.payload.totalElements;
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error?.message || "Error al cargar productos";
      })
      // Fetch Product poor Id
      .addCase(fetchProductById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProductById.fulfilled, (state, action) => {
        state.loading = false;
        state.selectedProduct = action.payload;
      })
      .addCase(fetchProductById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error?.message || "Error al cargar el producto";
      })
      // Fetch Categories
      .addCase(fetchCategories.fulfilled, (state, action) => {
        state.categories = action.payload;
      })
      // Create Product
      .addCase(createProduct.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })
      // Delete Product
      .addCase(deleteProduct.fulfilled, (state, action) => {
        state.items = state.items.filter((p) => p.id !== action.payload);
      })
      // Update Stock
      .addCase(updateStock.fulfilled, (state, action) => {
        const product = state.items.find((p) => p.id === action.payload.productId);
        if (product) {
          product.stock = action.payload.stock;
        }
      })
      // Update Discount
      .addCase(updateDiscount.fulfilled, (state, action) => {
        const product = state.items.find((p) => p.id === action.payload.productId);
        if (product) {
          product.discount = action.payload.discount;
        }
      });
  },
});

export default productsSlice.reducer;
export const { clearProducts, clearSelectedProduct } = productsSlice.actions;
