import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./authSlice";
import productsReducer from "./productsSlice";
import categoriesReducer from "./categoriesSlice";
import favoritesReducer from "./favoritesSlice";
import usersReducer from "./usersSlice";
import ordersReducer from "./ordersSlice";
import cartReducer from "../Redux/cartSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    products: productsReducer,
    categories: categoriesReducer,
    favorites: favoritesReducer,
    users: usersReducer,
    orders: ordersReducer,
    cart: cartReducer,
  },
});
