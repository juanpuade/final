import { createSlice } from "@reduxjs/toolkit";

const calculateTotal = (items) =>
  items.reduce((acc, item) => acc + item.price * item.quantity, 0);

const initialState = {
  cartItems: [],
  total: 0,
};

export const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const product = action.payload;
      const existing = state.cartItems.find((i) => i.id === product.id);

      // uso el stock desde el producto, si no tiene no hay limite
      const hasStockField = typeof product.stock === "number";
      const maxStock = hasStockField ? product.stock : undefined;

      if (existing) {
        // Si hay stock no lo dejo pasar 
        if (!hasStockField || existing.quantity < maxStock) {
          existing.quantity += 1;
        }
      } else {
        // Si no hay stock o el stock es mayor a 0 se agrega
        if (!hasStockField || maxStock > 0) {
          state.cartItems.push({ ...product, quantity: 1 });
        }
      }

      state.total = calculateTotal(state.cartItems);
    },

    increaseQuantity: (state, action) => {
      const id = action.payload;
      const item = state.cartItems.find((p) => p.id === id);
      if (!item) return;

      const hasStockField = typeof item.stock === "number";
      const maxStock = hasStockField ? item.stock : undefined;

      if (!hasStockField || item.quantity < maxStock) {
        item.quantity += 1;
      }

      state.total = calculateTotal(state.cartItems);
    },

    decreaseQuantity: (state, action) => {
      const id = action.payload;
      const item = state.cartItems.find((p) => p.id === id);

      if (item) {
        if (item.quantity > 1) {
          item.quantity -= 1;
        } else {
          state.cartItems = state.cartItems.filter((p) => p.id !== id);
        }
      }

      state.total = calculateTotal(state.cartItems);
    },

    removeFromCart: (state, action) => {
      const id = action.payload;
      state.cartItems = state.cartItems.filter((i) => i.id !== id);
      state.total = calculateTotal(state.cartItems);
    },

    clearCart: (state) => {
      state.cartItems = [];
      state.total = 0;
    },
  },
});

export const {
  addToCart,
  increaseQuantity,
  decreaseQuantity,
  removeFromCart,
  clearCart,
} = cartSlice.actions;

export default cartSlice.reducer;
